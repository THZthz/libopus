﻿/**
 * @file broadphase.c
 *     Author:    _              _
 *               / \   _ __ ___ (_)  __ _ ___
 *              / _ \ | '_ ` _ \| |/ _` / __|
 *             / ___ \| | | | | | | (_| \__ \
 *            /_/   \_\_| |_| |_|_|\__,_|___/  2022/4/12
 *
 * @brief Broad phase test for the collisions of bodies, includes:
 * 		     NAME            STATUS
 * 		1` sweep and prune     [X]
 * 		2` spatial hash        [O]
 * 		3` BVH tree            [X]
 * 		4` quad tree           [X]
 *
 * @example
 *
 * @note
 * 		I have no idea about the efficiency of stb_ds.h
 *
 */


#include "core/external/STB/stb_ds.h"
#include "impulse.h"


static int sort_asc_cb(const void *x, const void *y)
{
	int nx = *(const int *) x, ny = *(const int *) y;
	return (nx > ny) - (nx < ny); /* sign(-1, 0, 1) of nx - ny */
}

static int hash_key(impulse_spatial_hash_t *hash, impulse_vec2_t v)
{
	return (int) (v.y * hash->inv_cell_size) * (int) hash->bounds.width + (int) (v.x * hash->inv_cell_size);
}


impulse_spatial_hash_t *impulse_spatial_hash_create(Rectangle bounds, float cell_size)
{
	impulse_spatial_hash_t *hash;

	if (cell_size <= 0.0f) return NULL;

	hash = (impulse_spatial_hash_t *) malloc(sizeof(impulse_spatial_hash_t));
	if (hash == NULL) return NULL;

	hash->entries       = NULL;
	hash->query_cache   = NULL;
	hash->bounds        = bounds;
	hash->cell_size     = cell_size;
	hash->inv_cell_size = 1.0f / cell_size;
	return hash;
}

void impulse_spatial_hash_destroy(impulse_spatial_hash_t *hash)
{
	if (hash == NULL) return;

	if (hash->entries) {
		int i;
		for (i = 0; i < hmlen(hash->entries); i++)
			arrfree(hash->entries[i].values);

		hmfree(hash->entries);
	}

	free(hash);
}

void impulse_spatial_hash_add(impulse_spatial_hash_t *hash, Rectangle bound, int value)
{
	int x, y, x0, y0, x1, y1;

	if (hash == NULL || !impulse_is_rect_collided(hash->bounds, bound)) return;

	x0 = hash_key(hash, impulse_vec2(bound.x, 0));
	x1 = hash_key(hash, impulse_vec2(bound.x + bound.width, 0));

	y0 = hash_key(hash, impulse_vec2(0, bound.y));
	y1 = hash_key(hash, impulse_vec2(0, bound.y + bound.height));

	for (y = y0; y <= y1; y += (int) hash->bounds.width) {
		for (x = x0; x <= x1; x++) {
			const int                key   = x + y;
			impulse_spatial_entry_t *entry = hmgetp_null(hash->entries, key);

			if (entry != NULL) {
				arrput(entry->values, value);
			} else {
				impulse_spatial_entry_t new_entry;
				new_entry.key    = key;
				new_entry.values = NULL; /* leave to stb_ds.h to initialize */
				arrput(new_entry.values, value);
				hmputs(hash->entries, new_entry);
			}
		}
	}
}

void impulse_spatial_hash_clear(impulse_spatial_hash_t *hash)
{
	int i;

	IMPULSE_NOT_NULL(hash);

	for (i = 0; i < hmlen(hash->entries); i++)
		arrsetlen(hash->entries[i].values, 0);
}

void impulse_spatial_hash_remove(impulse_spatial_hash_t *hash, int key)
{
	impulse_spatial_entry_t entry;

	IMPULSE_NOT_NULL(hash);

	entry = hmgets(hash->entries, key);
	arrfree(entry.values);

	hmdel(hash->entries, key);
}

void impulse_spatial_hash_query(impulse_spatial_hash_t *hash, Rectangle rec, int **result)
{
	int x, y, x0, y0, x1, y1;
	int i, j; /* for loop */
	int old_len;

	IMPULSE_NOT_NULL(hash);
	IMPULSE_NOT_NULL(result);
	if (!impulse_is_rect_collided(hash->bounds, rec)) return;

	x0 = hash_key(hash, impulse_vec2(rec.x, 0));
	x1 = hash_key(hash, impulse_vec2(rec.x + rec.width, 0));

	y0 = hash_key(hash, impulse_vec2(0, rec.y));
	y1 = hash_key(hash, impulse_vec2(0, rec.y + rec.height));

	for (y = y0; y <= y1; y += (int) hash->bounds.width) {
		for (x = x0; x <= x1; x++) {
			const int                key   = x + y;
			impulse_spatial_entry_t *entry = hmgetp_null(hash->entries, key);

			if (entry != NULL) {
				for (j = 0; j < arrlen(entry->values); j++)
					arrput(*result, entry->values[j]);
			}
		}
	}

	old_len = arrlen(*result);
	if (old_len <= 1) return;

	/* sort result in ascending order */
	qsort(*result, old_len, sizeof(int), sort_asc_cb);

	arrsetlen(hash->query_cache, 0);

	/* filter out redundant value */
	for (i = 0; i < old_len; i++) {
		const int new_len = arrlen(hash->query_cache);

		if (new_len == 0 || hash->query_cache[new_len - 1] != (*result)[i])
			arrput(hash->query_cache, (*result)[i]);
	}

	arrsetlen(*result, 0);

	/* now the values in "result" is sorted and unique */
	for (i = 0; i < arrlen(hash->query_cache); i++)
		arrput(*result, hash->query_cache[i]);
}

void impulse_spatial_hash_set_bounds(impulse_spatial_hash_t *hash, Rectangle bounds)
{
	IMPULSE_NOT_NULL(hash);
	hash->bounds = bounds;
}

Rectangle impulse_spatial_hash_get_bounds(impulse_spatial_hash_t *hash)
{
	IMPULSE_NOT_NULL(hash);
	return hash->bounds;
}

float impulse_spatial_get_hash_cell_size(impulse_spatial_hash_t *hash)
{
	IMPULSE_NOT_NULL(hash);
	return hash->cell_size;
}

void impulse_spatial_set_hash_bounds(impulse_spatial_hash_t *hash, Rectangle bounds)
{
	IMPULSE_NOT_NULL(hash);
	hash->bounds = bounds;
}

void impulse_spatial_set_hash_cell_size(impulse_spatial_hash_t *hash, float cell_size)
{
	IMPULSE_NOT_NULL(hash);
	hash->cell_size = cell_size;
}
