﻿#include "impulse.h"


static impulse_collision_t impulse_collision_empty()
{
	impulse_collision_t ret;
	ret.check = false;
	return ret;
}

static impulse_raycast_hit_t impulse_raycast_hit_empty()
{
	impulse_raycast_hit_t ret;
	ret.check = false;
	return ret;
}

static bool               impulse_collision_check_AABB(impulse_shape_t *s1, impulse_transform_t tx1, impulse_shape_t *s2, impulse_transform_t tx2);
static int                impulse_polygon_get_furthest_point_idx(impulse_shape_t *s, impulse_transform_t tx, impulse_vec2_t v);
static impulse_vertices_t impulse_shape_get_significant_edge(impulse_shape_t *s, impulse_transform_t tx, impulse_vec2_t v);

static int impulse_get_separating_axis_idx(
        impulse_shape_t *s1, impulse_transform_t tx1,
        impulse_shape_t *s2, impulse_transform_t tx2,
        float *depth);


static impulse_collision_t impulse_SAT_circles(impulse_shape_t *s1, impulse_transform_t tx1, impulse_shape_t *s2, impulse_transform_t tx2);
static impulse_collision_t impulse_SAT_cir_poly(impulse_shape_t *s1, impulse_transform_t tx1, impulse_shape_t *s2, impulse_transform_t tx2);
static impulse_collision_t impulse_SAT_polygons(impulse_shape_t *s1, impulse_transform_t tx1, impulse_shape_t *s2, impulse_transform_t tx2);
static impulse_collision_t impulse_SAT(impulse_shape_t *s1, impulse_transform_t tx1, impulse_shape_t *s2, impulse_transform_t tx2);

static impulse_vertices_t impulse_clip_edge_with_axis(impulse_vertices_t e, impulse_vec2_t v, float min_dot);

static bool impulse_compute_intersection_rays(impulse_vec2_t o1, impulse_vec2_t v1, impulse_vec2_t o2, impulse_vec2_t v2, float *distance);
static bool impulse_compute_intersection_ray_circle(impulse_vec2_t o, impulse_vec2_t v, impulse_vec2_t c, float r, float *distance);

impulse_collision_t impulse_collision_check_shape(impulse_shape_t *s1, impulse_transform_t tx1, impulse_shape_t *s2, impulse_transform_t tx2)
{
	if (impulse_collision_check_AABB(s1, tx1, s2, tx2)) {
		return impulse_SAT(s1, tx1, s2, tx2);
	} else {
		return impulse_collision_empty();
	}
}

impulse_collision_t impulse_collision_check_body(impulse_body_t *b1, impulse_body_t *b2)
{
	if (b1 == NULL || b2 == NULL) {
		return impulse_collision_empty();
	}

	return impulse_collision_check_shape(
	        impulse_body_get_shape(b1),
	        impulse_body_get_transform(b1),
	        impulse_body_get_shape(b2),
	        impulse_body_get_transform(b2));
}

impulse_raycast_hit_t impulse_raycast_check_shape(impulse_shape_t *s, impulse_transform_t tx, impulse_ray_t ray)
{
	IMPULSE_NOT_NULL(s);
	if (impulse_shape_get_type(s) == IMPULSE_SHAPE_UNKNOWN) {
		return impulse_raycast_hit_empty();
	} else {
		int   i, j;
		float distance;

		impulse_raycast_hit_t ret;

		ret.distance  = IMPULSE_REAL_MAX;
		ret.shape     = s;
		ray.direction = impulse_vec2_norm(ray.direction);
		distance      = IMPULSE_REAL_MAX;

		if (impulse_shape_get_type(s) == IMPULSE_SHAPE_CIRCLE) {
			impulse_compute_intersection_ray_circle(
			        ray.origin, ray.direction,
			        tx.position, impulse_circle_get_radius(s),
			        &distance);

			ret.check  = (distance >= 0.0f) && (distance <= ray.max_dist);
			ret.inside = (distance < 0.0f);

			if (ret.check) {
				ret.distance = distance;

				ret.point = impulse_vec2_add(
				        ray.origin,
				        impulse_vec2_scalar_mult(ray.direction, ret.distance));

				ret.normal = impulse_vec2_left_norm(impulse_vec2_sub(ray.origin, ret.point));
			}

			return ret;
		} else if (impulse_shape_get_type(s) == IMPULSE_SHAPE_POLYGON) {
			int                intersectionCount = 0;
			impulse_vertices_t vertices          = impulse_polygon_get_vertices(s);

			for (j = vertices.count - 1, i = 0; i < vertices.count; j = i, i++) {
				impulse_vec2_t v1 = impulse_vec2_transform(vertices.data[i], tx);
				impulse_vec2_t v2 = impulse_vec2_transform(vertices.data[j], tx);

				impulse_vec2_t diff = impulse_vec2_sub(v1, v2);

				bool intersects = impulse_compute_intersection_rays(
				        ray.origin, ray.direction,
				        v2, diff,
				        &distance);

				if (intersects && distance <= ray.max_dist) {
					if (ret.distance > distance) {
						ret.distance = distance;

						ret.point = impulse_vec2_add(
						        ray.origin,
						        impulse_vec2_scalar_mult(ray.direction, ret.distance));

						ret.normal = impulse_vec2_left_norm(diff);
					}

					intersectionCount++;
				}
			}

			ret.inside = (intersectionCount & 1);
			ret.check  = (!ret.inside) && (intersectionCount > 0);

			return ret;
		}
	}
	return impulse_raycast_hit_empty();
}

impulse_raycast_hit_t impulse_raycast_check_body(impulse_body_t *b, impulse_ray_t ray)
{
	if (b == NULL || impulse_body_get_shape(b) == NULL)
		return IMPULSE_STRUCT_ZERO(impulse_raycast_hit_t);

	impulse_raycast_hit_t ret = impulse_raycast_check_shape(
	        impulse_body_get_shape(b), impulse_body_get_transform(b),
	        ray);

	ret.body = b;

	return ret;
}


/*====================
 * INTERNAL
 *====================*/

static bool impulse_collision_check_AABB(impulse_shape_t *s1, impulse_transform_t tx1, impulse_shape_t *s2, impulse_transform_t tx2)
{
	return impulse_is_rect_collided(impulse_shape_get_AABB(s1, tx1), impulse_shape_get_AABB(s2, tx2));
}

static int impulse_polygon_get_furthest_point_idx(impulse_shape_t *s, impulse_transform_t tx, impulse_vec2_t v)
{
	int   i;
	int   ret;
	float max_dot;

	impulse_vertices_t vertices;

	if (impulse_shape_get_type(s) != IMPULSE_SHAPE_POLYGON) return -1;

	vertices = impulse_polygon_get_vertices(s);

	max_dot = -IMPULSE_REAL_MAX;
	ret     = 0;

	v = impulse_vec2_rotate(v, -tx.rotation);

	for (i = 0; i < vertices.count; i++) {
		float dot = impulse_vec2_dot_product(vertices.data[i], v);

		if (max_dot < dot) {
			max_dot = dot;
			ret     = i;
		}
	}

	return ret;
}

static impulse_vertices_t impulse_shape_get_significant_edge(impulse_shape_t *s, impulse_transform_t tx, impulse_vec2_t v)
{
	impulse_vertices_t ret = {0};
	if (s == NULL || impulse_shape_get_type(s) == IMPULSE_SHAPE_UNKNOWN) IMPULSE_RET_EMPTY(impulse_vertices_t);

	if (impulse_shape_get_type(s) == IMPULSE_SHAPE_CIRCLE) {
		ret.data[0] = impulse_vec2_transform(
		        impulse_vec2_scalar_mult(v, impulse_circle_get_radius(s)),
		        tx);

		ret.count = 1;

		return ret;
	} else if (impulse_shape_get_type(s) == IMPULSE_SHAPE_POLYGON) {
		int furthest_idx = impulse_polygon_get_furthest_point_idx(s, tx, v);

		impulse_vertices_t vertices = impulse_polygon_get_vertices(s);

		int prev_idx = (furthest_idx == 0) ? vertices.count - 1 : furthest_idx - 1;
		int next_idx = (furthest_idx == vertices.count - 1) ? 0 : furthest_idx + 1;

		impulse_vec2_t furthest_vertex = impulse_vec2_transform(vertices.data[furthest_idx], tx);

		impulse_vec2_t prev_vertex = impulse_vec2_transform(vertices.data[prev_idx], tx);
		impulse_vec2_t next_vertex = impulse_vec2_transform(vertices.data[next_idx], tx);

		impulse_vec2_t left_v  = impulse_vec2_norm(impulse_vec2_sub(furthest_vertex, prev_vertex));
		impulse_vec2_t right_v = impulse_vec2_norm(impulse_vec2_sub(furthest_vertex, next_vertex));

		/* find the more perpendicular edge to "v" given */
		if (impulse_vec2_dot_product(left_v, v) < impulse_vec2_dot_product(right_v, v)) {
			ret.data[0] = prev_vertex;
			ret.data[1] = furthest_vertex;
		} else {
			ret.data[0] = furthest_vertex;
			ret.data[1] = next_vertex;
		}

		ret.count = 2;

		return ret;
	}
	return ret; /* should not be executed */
}

static int impulse_get_separating_axis_idx(
        impulse_shape_t *s1, impulse_transform_t tx1,
        impulse_shape_t *s2, impulse_transform_t tx2,
        float *depth)
{
	int                i, ret;
	float              max_dist;
	impulse_vertices_t normals;

	if (impulse_shape_get_type(s1) != IMPULSE_SHAPE_POLYGON || impulse_shape_get_type(s2) != IMPULSE_SHAPE_POLYGON)
		return -1;

	ret      = -1;
	normals  = impulse_polygon_get_normals(s1);
	max_dist = -IMPULSE_REAL_MAX;

	for (i = 0; i < normals.count; i++) {
		impulse_vec2_t vertex = impulse_vec2_transform(impulse_polygon_get_vertex(s1, i), tx1);
		impulse_vec2_t normal = impulse_vec2_rotate_tx(normals.data[i], tx1);

		int            furthest_idx    = impulse_polygon_get_furthest_point_idx(s2, tx2, impulse_vec2_neg(normal));
		impulse_vec2_t furthest_vertex = impulse_vec2_transform(impulse_polygon_get_vertex(s2, furthest_idx), tx2);

		float distance = impulse_vec2_dot_product(normal, impulse_vec2_sub(furthest_vertex, vertex));

		if (max_dist < distance) {
			max_dist = distance;
			ret      = i;
		}
	}

	*depth = max_dist;

	return ret;
}

static impulse_collision_t impulse_SAT_circles(impulse_shape_t *s1, impulse_transform_t tx1, impulse_shape_t *s2, impulse_transform_t tx2)
{
	impulse_collision_t ret = {0};
	impulse_vec2_t      diff;

	if (impulse_shape_get_type(s1) != IMPULSE_SHAPE_CIRCLE || impulse_shape_get_type(s2) != IMPULSE_SHAPE_CIRCLE)
		IMPULSE_RET_EMPTY(impulse_collision_t);

	diff = impulse_vec2_sub(tx2.position, tx1.position);

	float radiusSum    = impulse_circle_get_radius(s1) + impulse_circle_get_radius(s2);
	float magnitudeSqr = impulse_vec2_mag_sq(diff);

	if (radiusSum * radiusSum < magnitudeSqr) return ret;

	float diffMagnitude = sqrt(magnitudeSqr);

	ret.check = true;

	if (diffMagnitude > 0.0f) {
		ret.direction = impulse_vec2_scalar_mult(diff, 1.0f / diffMagnitude);

		impulse_vertices_t e = impulse_shape_get_significant_edge(s1, tx1, ret.direction);

		ret.points[0] = ret.points[1] = e.data[0];
		ret.depths[0] = ret.depths[1] = radiusSum - diffMagnitude;
	} else {
		ret.direction = (impulse_vec2_t){.x = 1.0f};

		impulse_vertices_t e = impulse_shape_get_significant_edge(s1, tx1, ret.direction);

		ret.points[0] = ret.points[1] = e.data[0];
		ret.depths[0] = ret.depths[1] = impulse_circle_get_radius(s1);
	}

	ret.count = 1;

	return ret;
}

static impulse_collision_t impulse_SAT_cir_poly(impulse_shape_t *s1, impulse_transform_t tx1, impulse_shape_t *s2, impulse_transform_t tx2)
{
	int i;
	if (impulse_shape_get_type(s1) == IMPULSE_SHAPE_UNKNOWN || impulse_shape_get_type(s2) == IMPULSE_SHAPE_UNKNOWN || impulse_shape_get_type(s1) == impulse_shape_get_type(s2))
		return IMPULSE_STRUCT_ZERO(impulse_collision_t);

	impulse_collision_t ret = IMPULSE_STRUCT_ZERO(impulse_collision_t);

	impulse_shape_t    *circle = s1, *polygon = s2;
	impulse_transform_t circleTx = tx1, polygonTx = tx2;

	if (impulse_shape_get_type(s1) == IMPULSE_SHAPE_POLYGON && impulse_shape_get_type(s2) == IMPULSE_SHAPE_CIRCLE) {
		circle = s2, polygon = s1;
		circleTx = tx2, polygonTx = tx1;
	}

	impulse_vertices_t vertices = impulse_polygon_get_vertices(polygon);
	impulse_vertices_t normals  = impulse_polygon_get_normals(polygon);


	impulse_vec2_t center = impulse_vec2_rotate(
	        impulse_vec2_sub(circleTx.position, polygonTx.position),
	        -polygonTx.rotation);

	float radius = impulse_circle_get_radius(circle), maxDistance = -IMPULSE_REAL_MAX;
	int   normalIndex = -1;


	for (i = 0; i < vertices.count; i++) {
		float distance = impulse_vec2_dot_product(
		        normals.data[i],
		        impulse_vec2_sub(center, vertices.data[i]));


		if (distance > radius) return ret;

		if (maxDistance < distance) {
			maxDistance = distance;
			normalIndex = i;
		}
	}


	if (maxDistance < 0.0f) {
		ret.check = true;

		ret.direction = impulse_vec2_neg(impulse_vec2_rotate_tx(normals.data[normalIndex], polygonTx));

		if (impulse_vec2_dot_product(impulse_vec2_sub(tx2.position, tx1.position), ret.direction) < 0.0f)
			ret.direction = impulse_vec2_neg(ret.direction);

		ret.points[0] = ret.points[1] = impulse_vec2_add(
		        circleTx.position,
		        impulse_vec2_scalar_mult(ret.direction, -radius));

		ret.depths[0] = ret.depths[1] = radius - maxDistance;

		ret.count = 1;
	} else {
		impulse_vec2_t v1 = (normalIndex > 0)
		                            ? vertices.data[normalIndex - 1]
		                            : vertices.data[vertices.count - 1];
		impulse_vec2_t v2 = vertices.data[normalIndex];

		impulse_vec2_t diff1 = impulse_vec2_sub(center, v1), diff2 = impulse_vec2_sub(center, v2);

		float v1Dot = impulse_vec2_dot_product(diff1, impulse_vec2_sub(v2, v1));
		float v2Dot = impulse_vec2_dot_product(diff2, impulse_vec2_sub(v1, v2));

		if (v1Dot <= 0.0f) {
			float magnitudeSqr = impulse_vec2_mag_sq(diff1);

			if (magnitudeSqr > radius * radius) return ret;

			ret.direction = impulse_vec2_norm(impulse_vec2_rotate_tx(impulse_vec2_neg(diff1), polygonTx));

			if (impulse_vec2_dot_product(impulse_vec2_sub(tx2.position, tx1.position), ret.direction) < 0.0f)
				ret.direction = impulse_vec2_neg(ret.direction);

			ret.points[0] = ret.points[1] = impulse_vec2_transform(v1, polygonTx);
			ret.depths[0] = ret.depths[1] = radius - sqrt(magnitudeSqr);
		} else if (v2Dot <= 0.0f) {
			float magnitudeSqr = impulse_vec2_mag_sq(diff2);

			if (magnitudeSqr > radius * radius) return ret;

			ret.direction = impulse_vec2_norm(impulse_vec2_rotate_tx(impulse_vec2_neg(diff2), polygonTx));

			if (impulse_vec2_dot_product(impulse_vec2_sub(tx2.position, tx1.position), ret.direction) < 0.0f)
				ret.direction = impulse_vec2_neg(ret.direction);

			ret.points[0] = ret.points[1] = impulse_vec2_transform(v2, polygonTx);
			ret.depths[0] = ret.depths[1] = radius - sqrt(magnitudeSqr);
		} else {
			impulse_vec2_t normal = normals.data[normalIndex];

			if (impulse_vec2_dot_product(diff1, normal) > radius) return ret;

			ret.direction = impulse_vec2_neg(impulse_vec2_rotate_tx(normal, polygonTx));

			if (impulse_vec2_dot_product(impulse_vec2_sub(tx2.position, tx1.position), ret.direction) < 0.0f)
				ret.direction = impulse_vec2_neg(ret.direction);

			ret.points[0] = ret.points[1] = impulse_vec2_add(
			        circleTx.position,
			        impulse_vec2_scalar_mult(ret.direction, -radius));

			ret.depths[0] = ret.depths[1] = radius - maxDistance;
		}

		ret.check = true;

		ret.count = 1;
	}

	return ret;
}

static impulse_collision_t impulse_SAT_polygons(impulse_shape_t *s1, impulse_transform_t tx1, impulse_shape_t *s2, impulse_transform_t tx2)
{
	float depth1, depth2;
	int   idx1, idx2;

	impulse_collision_t ret = {0};
	impulse_vec2_t      dir, ref_v, ref_normal;
	impulse_vertices_t  e1, e2, inc_edge, ref_edge;

	float dot1, dot2, ref_dot1, ref_dot2;
	float max_depth;

	if (impulse_shape_get_type(s1) != IMPULSE_SHAPE_POLYGON || impulse_shape_get_type(s2) != IMPULSE_SHAPE_POLYGON)
		IMPULSE_RET_EMPTY(impulse_collision_t);

	depth1 = IMPULSE_REAL_MAX;
	depth2 = IMPULSE_REAL_MAX;

	idx1 = impulse_get_separating_axis_idx(s1, tx1, s2, tx2, &depth1);
	if (depth1 >= 0.0f) IMPULSE_RET_EMPTY(impulse_collision_t);

	idx2 = impulse_get_separating_axis_idx(s2, tx2, s1, tx1, &depth2);
	if (depth2 >= 0.0f) IMPULSE_RET_EMPTY(impulse_collision_t);

	dir = (depth1 > depth2)
	              ? impulse_vec2_rotate_tx(impulse_polygon_get_normal(s1, idx1), tx1)
	              : impulse_vec2_rotate_tx(impulse_polygon_get_normal(s2, idx2), tx2);

	/* make sure the "dir" always points to "s2" */
	if (impulse_vec2_dot_product(impulse_vec2_sub(tx2.position, tx1.position), dir) < 0.0f)
		dir = impulse_vec2_neg(dir);

	ret.check     = true;
	ret.direction = dir;

	e1 = impulse_shape_get_significant_edge(s1, tx1, dir);
	e2 = impulse_shape_get_significant_edge(s2, tx2, impulse_vec2_neg(dir));

	ref_edge = e1, inc_edge = e2;

	dot1 = impulse_vec2_dot_product(impulse_vec2_sub(e1.data[1], e1.data[0]), dir);
	dot2 = impulse_vec2_dot_product(impulse_vec2_sub(e2.data[1], e2.data[0]), dir);

	extern impulse_collision_t _ret;

	ret.a_ = s2;

	/* reference edge is more perpendicular to "dir" */
	if (impulse_abs(dot1) > impulse_abs(dot2)) {
		ref_edge = e2;
		inc_edge = e1;
		ret.a_ = s1;
	}

	ref_v = impulse_vec2_norm(impulse_vec2_sub(ref_edge.data[1], ref_edge.data[0]));

	ref_dot1 = impulse_vec2_dot_product(ref_edge.data[0], ref_v);
	ref_dot2 = impulse_vec2_dot_product(ref_edge.data[1], ref_v);

	inc_edge = impulse_clip_edge_with_axis(inc_edge, ref_v, ref_dot1);
	inc_edge = impulse_clip_edge_with_axis(inc_edge, impulse_vec2_neg(ref_v), -ref_dot2);

	ref_normal = impulse_vec2_right_norm(ref_v);

	max_depth = impulse_vec2_dot_product(ref_edge.data[0], ref_normal);

	ret.points[0] = inc_edge.data[0], ret.points[1] = inc_edge.data[1];

	ret.depths[0] = impulse_vec2_dot_product(ret.points[0], ref_normal) - max_depth;
	ret.depths[1] = impulse_vec2_dot_product(ret.points[1], ref_normal) - max_depth;

	ret.count = 2;

	if (ret.depths[0] < 0.0f) {
		ret.points[0] = ret.points[1];
		ret.depths[0] = ret.depths[1];

		ret.count = 1;
	} else if (ret.depths[1] < 0.0f) {
		ret.points[1] = ret.points[0];
		ret.depths[1] = ret.depths[0];

		ret.count = 1;
	}

	_ret = ret;
	return ret;
}

static impulse_collision_t impulse_SAT(impulse_shape_t *s1, impulse_transform_t tx1, impulse_shape_t *s2, impulse_transform_t tx2)
{
	impulse_shape_type_t type1 = impulse_shape_get_type(s1);
	impulse_shape_type_t type2 = impulse_shape_get_type(s2);

	if (type1 == IMPULSE_SHAPE_UNKNOWN || type2 == IMPULSE_SHAPE_UNKNOWN)
		return IMPULSE_STRUCT_ZERO(impulse_collision_t);
	else if (type1 == IMPULSE_SHAPE_CIRCLE && type2 == IMPULSE_SHAPE_CIRCLE)
		return impulse_SAT_circles(s1, tx1, s2, tx2);
	else if (type1 == IMPULSE_SHAPE_CIRCLE && type2 == IMPULSE_SHAPE_POLYGON || type1 == IMPULSE_SHAPE_POLYGON && type2 == IMPULSE_SHAPE_CIRCLE)
		return impulse_SAT_cir_poly(s1, tx1, s2, tx2);
	else if (type1 == IMPULSE_SHAPE_POLYGON && type2 == IMPULSE_SHAPE_POLYGON)
		return impulse_SAT_polygons(s1, tx1, s2, tx2);
}

static impulse_vertices_t impulse_clip_edge_with_axis(impulse_vertices_t e, impulse_vec2_t v, float min_dot)
{
	impulse_vertices_t ret = {0};

	float p1Dot = impulse_vec2_dot_product(e.data[0], v) - min_dot;
	float p2Dot = impulse_vec2_dot_product(e.data[1], v) - min_dot;

	bool insideP1 = (p1Dot >= 0.0f), insideP2 = (p2Dot >= 0.0f);

	if (insideP1 && insideP2) {
		ret.data[0] = e.data[0];
		ret.data[1] = e.data[1];

		ret.count = 2;
	} else {
		impulse_vec2_t edgeV = impulse_vec2_sub(e.data[1], e.data[0]);

		float distance = p1Dot / (p1Dot - p2Dot);

		impulse_vec2_t midpoint = impulse_vec2_add(
		        e.data[0],
		        impulse_vec2_scalar_mult(edgeV, distance));

		if (insideP1 && !insideP2) {
			ret.data[0] = e.data[0];
			ret.data[1] = midpoint;

			ret.count = 2;
		} else if (!insideP1 && insideP2) {
			ret.data[0] = e.data[1];
			ret.data[1] = midpoint;

			ret.count = 2;
		}
	}

	return ret;
}

static bool impulse_compute_intersection_rays(impulse_vec2_t o1, impulse_vec2_t v1, impulse_vec2_t o2, impulse_vec2_t v2, float *distance)
{
	bool ret = true;

	float cross = impulse_vec2_cross_product(v1, v2);


	if (impulse_num_approx_eq(cross, 0.0f)) {
		*distance = 0.0f;

		return false;
	}

	impulse_vec2_t diff = impulse_vec2_sub(o2, o1);

	float inverseCross = 1.0f / cross;

	float t = impulse_vec2_cross_product(diff, v2) * inverseCross;
	float u = impulse_vec2_cross_product(diff, v1) * inverseCross;


	if (t < 0.0f || u < 0.0f || u > 1.0f) ret = false;

	*distance = t;

	return ret;
}

static bool impulse_compute_intersection_ray_circle(impulse_vec2_t o, impulse_vec2_t v, impulse_vec2_t c, float r, float *distance)
{
	bool ret = true;

	impulse_vec2_t diff = impulse_vec2_sub(c, o);

	float dot        = impulse_vec2_dot_product(diff, v);
	float height_sqr = impulse_vec2_mag_sq(diff) - (dot * dot);
	float base_sqr   = (r * r) - height_sqr;

	if (dot < 0.0f || base_sqr < 0.0f) ret = false;

	*distance = dot - impulse_sqrt(base_sqr);

	return ret;
}
