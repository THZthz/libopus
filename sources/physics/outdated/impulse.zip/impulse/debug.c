﻿#include "impulse.h"

const float ARROW_HEAD_LENGTH = 16.0f;

#define vec_cast(v) (*(Vector2 *) &(v))


#ifndef FEROX_STANDALONE

static impulse_vertices_t impulse_get_world_vertices_in_pixels(impulse_body_t *b);

void impulse_draw_arrow(impulse_vec2_t p1, impulse_vec2_t p2, float thick, Color color)
{
	if (thick <= 0.0f) return;

	p1 = impulse_vec2_m2p(p1);
	p2 = impulse_vec2_m2p(p2);

	impulse_vec2_t diff = impulse_vec2_norm(impulse_vec2_sub(p1, p2));

	impulse_vec2_t normal1 = impulse_vec2_left_norm(diff);
	impulse_vec2_t normal2 = impulse_vec2_right_norm(diff);

	impulse_vec2_t h1 = impulse_vec2_add(
	        p2,
	        impulse_vec2_scalar_mult(
	                impulse_vec2_norm(impulse_vec2_add(diff, normal1)),
	                ARROW_HEAD_LENGTH));

	impulse_vec2_t h2 = impulse_vec2_add(
	        p2,
	        impulse_vec2_scalar_mult(
	                impulse_vec2_norm(impulse_vec2_add(diff, normal2)),
	                ARROW_HEAD_LENGTH));

	DrawLineEx(vec_cast(p1), vec_cast(p2), thick, color);
	DrawLineEx(vec_cast(p2), vec_cast(h1), thick, color);
	DrawLineEx(vec_cast(p2), vec_cast(h2), thick, color);
}

void impulse_draw_body(impulse_body_t *b, Color color)
{
	impulse_shape_t *s;

	if (b == NULL) return;

	s = impulse_body_get_shape(b);

	if (impulse_shape_get_type(s) == IMPULSE_SHAPE_CIRCLE) {
		impulse_vec2_t c = impulse_vec2_m2p(impulse_body_get_position(b));
		DrawCircleV(
		        vec_cast(c),
		        impulse_num_p2m(impulse_circle_get_radius(s)),
		        color);
	} else if (impulse_shape_get_type(s) == IMPULSE_SHAPE_POLYGON) {
		impulse_vertices_t world_verts = impulse_get_world_vertices_in_pixels(b);
		DrawTriangleFan((Vector2 *) world_verts.data, world_verts.count, color);
	}
}

void impulse_draw_body_lines(impulse_body_t *b, float thick, Color color)
{
	if (b == NULL || thick <= 0.0f) return;

	impulse_shape_t *s = impulse_body_get_shape(b);

	if (impulse_shape_get_type(s) == IMPULSE_SHAPE_CIRCLE) {
		impulse_vec2_t p = impulse_body_get_position(b);
		impulse_vec2_t c = impulse_vec2_m2p(p);

		DrawRing(
		        vec_cast(c),
		        impulse_num_p2m(impulse_circle_get_radius(s)) - thick,
		        impulse_num_p2m(impulse_circle_get_radius(s)),
		        0.0f,
		        360.0f,
		        IMPULSE_DEBUG_CIRCLE_SEGMENT_COUNT,
		        color);
	} else if (impulse_shape_get_type(s) == IMPULSE_SHAPE_POLYGON) {
		impulse_vertices_t world_vertices = impulse_get_world_vertices_in_pixels(b);

		int                i,j;
		for (j = world_vertices.count - 1, i = 0; i < world_vertices.count; j = i, i++)
			DrawLineEx(vec_cast(world_vertices.data[j]), vec_cast(world_vertices.data[i]), thick, color);
	}
}

void impulse_draw_body_AABB(impulse_body_t *b, float thick, Color color)
{
	impulse_vec2_t c;
	Rectangle      aabb;

	if (b == NULL || thick <= 0.0f) return;

	aabb = impulse_body_get_AABB(b);

	DrawRectangleLinesEx(
	        (Rectangle){
	                impulse_num_p2m(aabb.x),
	                impulse_num_p2m(aabb.y),
	                impulse_num_p2m(aabb.width),
	                impulse_num_p2m(aabb.height)},
	        thick,
	        color);

	c = impulse_vec2_m2p(impulse_body_get_position(b));
	DrawCircleV(vec_cast(c), 2.0f, color);
}

void impulse_draw_body_props(impulse_body_t *b, Color color)
{
	impulse_vec2_t velocity = impulse_body_get_velocity(b);

	impulse_transform_t tx = impulse_body_get_transform(b);

	impulse_vec2_t p = impulse_vec2_m2p(impulse_vec2_add(tx.position, impulse_vec2(1.0f, 1.0f)));

	DrawTextEx(
	        GetFontDefault(),
	        TextFormat(
	                "m: %fkg, I: %fkg*m²\n"
	                "(x, y) [theta]: (%f, %f) [%f rad.]\n"
	                "v [omega]: (%f, %f) [%f rad.]\n",
	                impulse_body_get_mass(b), impulse_body_get_inertia(b),
	                tx.position.x, tx.position.y, tx.rotation,
	                velocity.x, velocity.y, impulse_body_get_angular_velocity(b)),
	        vec_cast(p),
	        10.0f,
	        1.0f,
	        color);
}

void impulse_draw_spatial_hash(impulse_spatial_hash_t *hm, float thick, Color color)
{
	int i;

	if (hm == NULL || thick <= 0.0f) return;

	Rectangle bounds = impulse_spatial_hash_get_bounds(hm);

	const int vCount = bounds.width * IMPULSE_BROADPHASE_INVERSE_CELL_SIZE;
	const int hCount = bounds.height * IMPULSE_BROADPHASE_INVERSE_CELL_SIZE;

	for ( i = 0; i <= vCount; i++) {
		impulse_vec2_t sp = impulse_vec2_m2p(impulse_vec2(IMPULSE_BROADPHASE_CELL_SIZE * i, 0.0f));
		impulse_vec2_t ep = impulse_vec2_m2p(impulse_vec2(IMPULSE_BROADPHASE_CELL_SIZE * i, bounds.height));
		DrawLineEx(
		        vec_cast(sp),
		        vec_cast(ep),
		        thick,
		        color);
	}

	for ( i = 0; i <= hCount; i++) {
		impulse_vec2_t sp = impulse_vec2_m2p(impulse_vec2(0.0f, IMPULSE_BROADPHASE_CELL_SIZE * i));
		impulse_vec2_t ep = impulse_vec2_m2p(impulse_vec2(bounds.width, IMPULSE_BROADPHASE_CELL_SIZE * i));
		DrawLineEx(
		        vec_cast(sp),
		        vec_cast(ep),
		        thick,
		        color);
	}


	DrawRectangleLinesEx(impulse_rect_m2p(bounds), thick, color);
}

static impulse_vertices_t impulse_get_world_vertices_in_pixels(impulse_body_t *b)
{
	int i;

	if (b == NULL) return IMPULSE_STRUCT_ZERO(impulse_vertices_t);

	impulse_vertices_t vertices = impulse_polygon_get_vertices(impulse_body_get_shape(b));

	for ( i = 0; i < vertices.count; i++)
		vertices.data[i] = impulse_vec2_m2p(impulse_body_get_world_point(b, vertices.data[i]));

	return vertices;
}
#endif
