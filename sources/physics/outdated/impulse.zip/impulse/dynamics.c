﻿#include <math.h>

#include "impulse.h"

static void impulse_body_reset_mass(impulse_body_t *b);

impulse_body_t *impulse_body_create(impulse_body_type_t type, impulse_body_flags_t flags, impulse_vec2_t p)
{
	if (type == IMPULSE_BODY_UNKNOWN) return NULL;

	impulse_body_t *result = calloc(1, sizeof(impulse_body_t));

	result->material = IMPULSE_STRUCT_ZERO(impulse_material_t);

	impulse_body_set_type(result, type);
	impulse_body_set_flags(result, flags);
	impulse_body_set_gravity_scale(result, 1.0f);
	impulse_body_set_position(result, p);

	return result;
}

impulse_body_t *impulse_body_create_from_shape(impulse_body_type_t type, impulse_body_flags_t flags, impulse_vec2_t p, impulse_shape_t *s)
{
	if (type == IMPULSE_BODY_UNKNOWN) return NULL;

	impulse_body_t *result = impulse_body_create(type, flags, p);
	impulse_body_attach_shape(result, s);

	return result;
}

void impulse_body_destroy(impulse_body_t *b)
{
	if (b != NULL && b->shape != NULL)
		impulse_body_detach_shape(b);

	free(b);
}

void impulse_body_attach_shape(impulse_body_t *b, impulse_shape_t *s)
{
	if (b == NULL || s == NULL) return;

	b->shape    = s;
	b->material = impulse_shape_get_material(s);
	b->aabb     = impulse_shape_get_AABB(b->shape, b->tx);
	s->body = b;

	impulse_body_reset_mass(b);
}

void impulse_body_detach_shape(impulse_body_t *b)
{
	if (b == NULL) return;

	b->shape    = NULL;
	b->material = IMPULSE_STRUCT_ZERO(impulse_material_t);
	b->aabb     = IMPULSE_STRUCT_ZERO(Rectangle);

	impulse_body_reset_mass(b);
}

impulse_body_type_t impulse_body_get_type(impulse_body_t *b)
{
	return (b != NULL) ? b->type : IMPULSE_BODY_UNKNOWN;
}

impulse_body_flags_t impulse_body_get_flags(impulse_body_t *b)
{
	return (b != NULL) ? b->flags : 0;
}

impulse_material_t impulse_body_get_material(impulse_body_t *b)
{
	return (b != NULL) ? b->material : IMPULSE_STRUCT_ZERO(impulse_material_t);
}

float impulse_body_get_mass(impulse_body_t *b)
{
	return (b != NULL) ? b->motion.mass : 0.0f;
}

float impulse_body_get_inv_mass(impulse_body_t *b)
{
	return (b != NULL) ? b->motion.inverseMass : 0.0f;
}

float impulse_body_get_inertia(impulse_body_t *b)
{
	return (b != NULL) ? b->motion.inertia : 0.0f;
}

float impulse_body_get_inv_inertia(impulse_body_t *b)
{
	return (b != NULL) ? b->motion.inverseInertia : 0.0f;
}

impulse_vec2_t impulse_body_get_velocity(impulse_body_t *b)
{
	return (b != NULL) ? b->motion.velocity : IMPULSE_STRUCT_ZERO(impulse_vec2_t);
}

float impulse_body_get_angular_velocity(impulse_body_t *b)
{
	return (b != NULL) ? b->motion.angularVelocity : 0.0f;
}

float impulse_body_get_gravity_scale(impulse_body_t *b)
{
	return (b != NULL) ? b->motion.gravityScale : 0.0f;
}

impulse_transform_t impulse_body_get_transform(impulse_body_t *b)
{
	return (b != NULL) ? b->tx : IMPULSE_STRUCT_ZERO(impulse_transform_t);
}

impulse_vec2_t impulse_body_get_position(impulse_body_t *b)
{
	return (b != NULL) ? b->tx.position : IMPULSE_STRUCT_ZERO(impulse_vec2_t);
}

float impulse_body_get_rotation(impulse_body_t *b)
{
	return (b != NULL) ? b->tx.rotation : 0.0f;
}

impulse_shape_t *impulse_body_get_shape(impulse_body_t *b)
{
	return (b != NULL) ? b->shape : NULL;
}

Rectangle impulse_body_get_AABB(impulse_body_t *b)
{
	return (b != NULL && b->shape != NULL) ? b->aabb : IMPULSE_STRUCT_ZERO(Rectangle);
}

impulse_vec2_t impulse_body_get_local_point(impulse_body_t *b, impulse_vec2_t p)
{
	return impulse_vec2_transform(p, (impulse_transform_t){impulse_vec2_neg(b->tx.position), -(b->tx.rotation)});
}

impulse_vec2_t impulse_body_get_world_point(impulse_body_t *b, impulse_vec2_t p)
{
	return impulse_vec2_transform(p, b->tx);
}

void impulse_body_set_type(impulse_body_t *b, impulse_body_type_t type)
{
	if (b == NULL || b->type == IMPULSE_BODY_UNKNOWN || b->type == type)
		return;

	b->type = type;

	impulse_body_reset_mass(b);
}

void impulse_body_set_flags(impulse_body_t *b, impulse_body_flags_t flags)
{
	if (b == NULL || b->flags == flags) return;

	b->flags = flags;

	impulse_body_reset_mass(b);
}

void impulse_body_set_velocity(impulse_body_t *b, impulse_vec2_t v)
{
	if (b != NULL) b->motion.velocity = v;
}

void impulse_body_set_angular_velocity(impulse_body_t *b, double a)
{
	if (b != NULL) b->motion.angularVelocity = a;
}

void impulse_body_set_gravity_scale(impulse_body_t *b, float scale)
{
	if (b == NULL || b->type != IMPULSE_BODY_DYNAMIC) return;

	b->motion.gravityScale = scale;
}

void impulse_body_set_transform(impulse_body_t *b, impulse_transform_t tx)
{
	if (b == NULL) return;

	b->tx.position = tx.position;
	b->tx.rotation = impulse_norm_angle(tx.rotation, PI);

	b->tx.cache.valid = true;
	b->tx.cache.sin_a = sin(b->tx.rotation);
	b->tx.cache.cos_a = cos(b->tx.rotation);

	b->aabb = impulse_shape_get_AABB(b->shape, b->tx);
}

void impulse_body_set_position(impulse_body_t *b, impulse_vec2_t p)
{
	if (b == NULL) return;

	b->tx.position = p;
	b->aabb        = impulse_shape_get_AABB(b->shape, b->tx);
}

void impulse_body_set_rotation(impulse_body_t *b, float rotation)
{
	if (b == NULL) return;

	b->tx.rotation = impulse_norm_angle(rotation, PI);

	b->tx.cache.valid = true;
	b->tx.cache.sin_a = sin(b->tx.rotation);
	b->tx.cache.cos_a = cos(b->tx.rotation);

	b->aabb = impulse_shape_get_AABB(b->shape, b->tx);
}

void impulse_apply_gravity(impulse_body_t *b, impulse_vec2_t gravity)
{
	if (b == NULL || b->motion.inverseMass <= 0.0f) return;

	b->motion.force = impulse_vec2_add(
	        b->motion.force,
	        impulse_vec2_scalar_mult(
	                gravity,
	                b->motion.gravityScale * b->motion.mass));
}

void impulse_apply_impulse(impulse_body_t *b, impulse_vec2_t impulse)
{
	if (b == NULL || b->motion.inverseMass <= 0.0f) return;

	b->motion.velocity = impulse_vec2_add(
	        b->motion.velocity,
	        impulse_vec2_scalar_mult(
	                impulse,
	                b->motion.inverseMass));
}

void impulse_apply_torque_impulse(impulse_body_t *b, impulse_vec2_t p, impulse_vec2_t impulse)
{
	if (b == NULL || b->motion.inverseInertia <= 0.0f) return;

	b->motion.angularVelocity += b->motion.inverseInertia * impulse_vec2_cross_product(p, impulse);
}

void impulse_body_clear_forces(impulse_body_t *b)
{
	if (b == NULL) return;

	b->motion.force  = impulse_vec2(0, 0);
	b->motion.torque = 0.0f;
}

void impulse_integrate_for_body_position(impulse_body_t *b, double dt)
{
	if (b == NULL || b->type == IMPULSE_BODY_STATIC) return;

	impulse_body_set_position(b, impulse_vec2_add(b->tx.position, impulse_vec2_scalar_mult(b->motion.velocity, dt)));
	impulse_body_set_rotation(b, b->tx.rotation + (b->motion.angularVelocity * dt));
}

void impulse_integrate_for_body_velocity(impulse_body_t *b, double dt)
{
	if (b == NULL || b->motion.inverseMass <= 0.0f) return;

	const float half_dt = 0.5f * dt;

	b->motion.velocity = impulse_vec2_add(
	        b->motion.velocity,
	        impulse_vec2_scalar_mult(
	                b->motion.force,
	                b->motion.inverseMass * half_dt));

	b->motion.angularVelocity += (b->motion.torque * b->motion.inverseInertia) * half_dt;
}

void impulse_resolve_collision(impulse_collision_t *collision)
{
	int i;
	if (collision == NULL || !collision->check) return;

	impulse_body_t *b1 = collision->cache.bodies[0];
	impulse_body_t *b2 = collision->cache.bodies[1];

	if (b1 == NULL || b2 == NULL) return;

	if (b1->motion.inverseMass + b2->motion.inverseMass <= 0.0f) {
		if (impulse_body_get_type(b1) == IMPULSE_BODY_STATIC) b1->motion.velocity = IMPULSE_STRUCT_ZERO(impulse_vec2_t);
		if (impulse_body_get_type(b2) == IMPULSE_BODY_STATIC) b2->motion.velocity = IMPULSE_STRUCT_ZERO(impulse_vec2_t);

		return;
	}

	float epsilon = b1->material.restitution < b2->material.restitution ? b1->material.restitution : b2->material.restitution;
	epsilon = epsilon > 0 ? epsilon : 0;

	float staticMu  = b1->material.static_friction * b2->material.static_friction;
	float dynamicMu = b1->material.dynamic_friction * b2->material.dynamic_friction;


	if (staticMu < dynamicMu) dynamicMu = IMPULSE_DYNAMICS_DYNAMIC_FRICTION_MULTIPLIER * staticMu;

	for ( i = 0; i < collision->count; i++) {
		impulse_vec2_t r1 = impulse_vec2_sub(collision->points[i], impulse_body_get_position(b1));
		impulse_vec2_t r2 = impulse_vec2_sub(collision->points[i], impulse_body_get_position(b2));

		impulse_vec2_t r1Normal = impulse_vec2_left_norm(r1);
		impulse_vec2_t r2Normal = impulse_vec2_left_norm(r2);


		impulse_vec2_t relativeVelocity = impulse_vec2_sub(
		        impulse_vec2_add(
		                b2->motion.velocity,
		                impulse_vec2_scalar_mult(r2Normal, b2->motion.angularVelocity)),
		        impulse_vec2_add(
		                b1->motion.velocity,
		                impulse_vec2_scalar_mult(r1Normal, b1->motion.angularVelocity)));

		float relativeVelocityDot = impulse_vec2_dot_product(relativeVelocity, collision->direction);


		if (relativeVelocityDot > 0.0f) return;

		float r1NormalDot = impulse_vec2_dot_product(r1Normal, collision->direction);
		float r2NormalDot = impulse_vec2_dot_product(r2Normal, collision->direction);

		float inverseMassSum = (b1->motion.inverseMass + b2->motion.inverseMass) + b1->motion.inverseInertia * (r1NormalDot * r1NormalDot) + b2->motion.inverseInertia * (r2NormalDot * r2NormalDot);

		float impulseParam = (-(1.0f + epsilon) * relativeVelocityDot) / (collision->count * inverseMassSum);

		impulse_vec2_t impulse = impulse_vec2_scalar_mult(collision->direction, impulseParam);

		impulse_apply_impulse(b1, impulse_vec2_neg(impulse));
		impulse_apply_torque_impulse(b1, r1, impulse_vec2_neg(impulse));

		impulse_apply_impulse(b2, impulse);
		impulse_apply_torque_impulse(b2, r2, impulse);


		relativeVelocity = impulse_vec2_sub(
		        impulse_vec2_add(
		                b2->motion.velocity,
		                impulse_vec2_scalar_mult(r2Normal, b2->motion.angularVelocity)),
		        impulse_vec2_add(
		                b1->motion.velocity,
		                impulse_vec2_scalar_mult(r1Normal, b1->motion.angularVelocity)));

		relativeVelocityDot = impulse_vec2_dot_product(relativeVelocity, collision->direction);

		impulse_vec2_t tangent = impulse_vec2_norm(
		        impulse_vec2_sub(
		                relativeVelocity,
		                impulse_vec2_scalar_mult(collision->direction, relativeVelocityDot)));

		r1NormalDot = impulse_vec2_dot_product(r1Normal, tangent);
		r2NormalDot = impulse_vec2_dot_product(r2Normal, tangent);

		inverseMassSum = (b1->motion.inverseMass + b2->motion.inverseMass) + b1->motion.inverseInertia * (r1NormalDot * r1NormalDot) + b2->motion.inverseInertia * (r2NormalDot * r2NormalDot);

		float frictionParam = -impulse_vec2_dot_product(relativeVelocity, tangent) / (collision->count * inverseMassSum);

		impulse_vec2_t friction = (fabsf(frictionParam) < impulseParam * staticMu)
		                                  ? impulse_vec2_scalar_mult(tangent, frictionParam)
		                                  : impulse_vec2_scalar_mult(tangent, -impulseParam * dynamicMu);

		impulse_apply_impulse(b1, impulse_vec2_neg(friction));
		impulse_apply_torque_impulse(b1, r1, impulse_vec2_neg(friction));

		impulse_apply_impulse(b2, friction);
		impulse_apply_torque_impulse(b2, r2, friction);
	}
}

void impulse_correct_body_position(impulse_collision_t *collision, float inverseDt)
{
	if (collision == NULL || !collision->check) return;

	impulse_body_t *b1 = collision->cache.bodies[0];
	impulse_body_t *b2 = collision->cache.bodies[1];

	if (b1 == NULL || b2 == NULL) return;

	if (b1->motion.inverseMass + b2->motion.inverseMass <= 0.0f) {
		if (impulse_body_get_type(b1) == IMPULSE_BODY_STATIC) b1->motion.velocity = IMPULSE_STRUCT_ZERO(impulse_vec2_t);
		if (impulse_body_get_type(b2) == IMPULSE_BODY_STATIC) b2->motion.velocity = IMPULSE_STRUCT_ZERO(impulse_vec2_t);

		return;
	}

	float maxDepth = collision->depths[0] > collision->depths[1] ? collision->depths[0] : collision->depths[1];

	if (maxDepth <= IMPULSE_DYNAMICS_CORRECTION_DEPTH_THRESHOLD) return;


	impulse_vec2_t correction = impulse_vec2_scalar_mult(
	        collision->direction,
	        IMPULSE_DYNAMICS_CORRECTION_DEPTH_SCALE * ((inverseDt * (maxDepth - IMPULSE_DYNAMICS_CORRECTION_DEPTH_THRESHOLD)) / (b1->motion.inverseMass + b2->motion.inverseMass)));

	impulse_body_set_position(
	        b1,
	        impulse_vec2_sub(
	                b1->tx.position,
	                impulse_vec2_scalar_mult(correction, b1->motion.inverseMass)));
	impulse_body_set_position(
	        b2,
	        impulse_vec2_add(
	                b2->tx.position,
	                impulse_vec2_scalar_mult(correction, b2->motion.inverseMass)));
}

static void impulse_body_reset_mass(impulse_body_t *b)
{
	if (b == NULL) return;

	b->motion.mass    = 0.0f;
	b->motion.inertia = 0.0f;

	if (b->type == IMPULSE_BODY_STATIC) {
		b->motion.velocity        = IMPULSE_STRUCT_ZERO(impulse_vec2_t);
		b->motion.angularVelocity = 0.0f;
	} else if (b->type == IMPULSE_BODY_DYNAMIC) {
		if (b->shape != NULL) {
			if (!(b->flags & IMPULSE_FLAG_INFINITE_MASS))
				b->motion.mass = impulse_shape_get_mass(b->shape);

			if (!(b->flags & IMPULSE_FLAG_INFINITE_INERTIA))
				b->motion.inertia = impulse_shape_get_inertia(b->shape);
		}
	}

	if (b->motion.mass == 0.0f) b->motion.inverseMass = 0.0f;
	else
		b->motion.inverseMass = 1.0f / b->motion.mass;

	if (b->motion.inertia == 0.0f) b->motion.inverseInertia = 0.0f;
	else
		b->motion.inverseInertia = 1.0f / b->motion.inertia;
}
