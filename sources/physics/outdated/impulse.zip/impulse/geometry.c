﻿#include "impulse.h"


const float INVERSE_TWELVE = (1.0f / 12.0f);

static void               impulse_compute_area(impulse_shape_t *s);
static void               impulse_compute_convex(impulse_shape_t *s);
static impulse_vertices_t impulse_jarvis_march(impulse_vertices_t *vertices);

impulse_shape_t *impulse_circle_create(impulse_material_t material, float radius)
{
	impulse_shape_t *result = impulse_shape_create();

	result->type     = IMPULSE_SHAPE_CIRCLE;
	result->material = material;

	impulse_circle_set_radius(result, radius);

	return result;
}

impulse_shape_t *impulse_rectangle_create(impulse_material_t material, float width, float height)
{
	impulse_shape_t *result = impulse_shape_create();

	const float half_width = 0.5f * width, half_height = 0.5f * height;

	impulse_vertices_t vertices = {
	        .data = {
	                impulse_vec2(-half_width,  -half_height),
	                impulse_vec2(-half_width,  half_height),
	                impulse_vec2(half_width,  half_height),
	                impulse_vec2(half_width,  -half_height)},
	        .count = 4};

	result->type     = IMPULSE_SHAPE_POLYGON;
	result->material = material;
	result->is_rect  = true;

	impulse_polygon_set_vertices(result, vertices);

	return result;
}

impulse_shape_t *impulse_polygon_create(impulse_material_t material, impulse_vertices_t vertices)
{
	impulse_shape_t *result = impulse_shape_create();

	if (vertices.count > IMPULSE_GEOMETRY_MAX_VERTEX_COUNT)
		vertices.count = IMPULSE_GEOMETRY_MAX_VERTEX_COUNT;

	result->type     = IMPULSE_SHAPE_POLYGON;
	result->material = material;

	impulse_polygon_set_vertices(result, vertices);

	return result;
}

impulse_shape_t *impulse_shape_create(void)
{
	impulse_shape_t *result = calloc(1, sizeof(impulse_shape_t));

	result->type = IMPULSE_SHAPE_UNKNOWN;

	return result;
}

impulse_shape_t *impulse_shape_clone(impulse_shape_t *s)
{
	if (s == NULL || s->type == IMPULSE_SHAPE_UNKNOWN) return NULL;

	impulse_shape_t *result = impulse_shape_create();

	result->type     = s->type;
	result->material = s->material;
	result->is_rect  = s->is_rect;
	result->area     = s->area;

	if (result->type == IMPULSE_SHAPE_CIRCLE) {
		result->circle.radius = s->circle.radius;
	} else if (result->type == IMPULSE_SHAPE_POLYGON) {
		int i;

		result->polygon.vertices.count = s->polygon.vertices.count;
		result->polygon.normals.count  = s->polygon.normals.count;

		for ( i = 0; i < s->polygon.vertices.count; i++)
			result->polygon.vertices.data[i] = s->polygon.vertices.data[i];

		for ( i = 0; i < s->polygon.normals.count; i++)
			result->polygon.normals.data[i] = s->polygon.normals.data[i];
	}

	return result;
}

void impulse_shape_destroy(impulse_shape_t *s)
{
	free(s);
}

impulse_shape_type_t impulse_shape_get_type(impulse_shape_t *s)
{
	return (s != NULL) ? s->type : IMPULSE_SHAPE_UNKNOWN;
}

impulse_material_t impulse_shape_get_material(impulse_shape_t *s)
{
	return (s != NULL) ? s->material : IMPULSE_STRUCT_ZERO(impulse_material_t);
}

float impulse_shape_get_area(impulse_shape_t *s)
{
	return (s != NULL && s->area >= 0.0f) ? s->area : 0.0f;
}

float impulse_shape_get_mass(impulse_shape_t *s)
{
	return (s != NULL) ? s->material.density * impulse_shape_get_area(s) : 0.0f;
}

float impulse_shape_get_inertia(impulse_shape_t *s)
{
	if (s == NULL || s->type == IMPULSE_SHAPE_UNKNOWN) return 0.0f;

	float result = 0.0f;

	if (s->type == IMPULSE_SHAPE_CIRCLE) {
		result = 0.5f * impulse_shape_get_mass(s) * (impulse_circle_get_radius(s) * impulse_circle_get_radius(s));
	} else if (s->type == IMPULSE_SHAPE_POLYGON) {
		float xInertia = 0.0f, yInertia = 0.0f;
	int i, j;

		for ( j = s->polygon.vertices.count - 1, i = 0; i < s->polygon.vertices.count; j = i, i++) {
			impulse_vec2_t v1 = s->polygon.vertices.data[j];
			impulse_vec2_t v2 = s->polygon.vertices.data[i];

			float cross = impulse_vec2_cross_product(v1, v2);

			xInertia += cross * ((v1.y * v1.y) + (v1.y * v2.y) + (v2.y * v2.y));
			yInertia += cross * ((v1.x * v1.x) + (v1.x * v2.x) + (v2.x * v2.x));
		}

		result = fabsf((xInertia + yInertia) * INVERSE_TWELVE);
	}

	return s->material.density * result;
}

Rectangle impulse_shape_get_AABB(impulse_shape_t *s, impulse_transform_t tx)
{
	Rectangle result = IMPULSE_STRUCT_ZERO(Rectangle);

	if (s == NULL || s->type == IMPULSE_SHAPE_UNKNOWN)
		return result;

	if (s->type == IMPULSE_SHAPE_CIRCLE) {
		result.x = tx.position.x - (s->circle.radius);
		result.y = tx.position.y - (s->circle.radius);

		result.width = result.height = 2.0f * (s->circle.radius);

		return result;
	} else if (s->type == IMPULSE_SHAPE_POLYGON) {
		int i;
		impulse_vec2_t minVertex = {FLT_MAX, FLT_MAX};
		impulse_vec2_t maxVertex = {-FLT_MAX, -FLT_MAX};


		for ( i = 0; i < s->polygon.vertices.count; i++) {
			impulse_vec2_t vertex = impulse_vec2_transform(s->polygon.vertices.data[i], tx);

			if (minVertex.x > vertex.x) minVertex.x = vertex.x;
			if (minVertex.y > vertex.y) minVertex.y = vertex.y;

			if (maxVertex.x < vertex.x) maxVertex.x = vertex.x;
			if (maxVertex.y < vertex.y) maxVertex.y = vertex.y;
		}

		float deltaX = maxVertex.x - minVertex.x;
		float deltaY = maxVertex.y - minVertex.y;

		result.x = minVertex.x;
		result.y = minVertex.y;

		result.width  = deltaX;
		result.height = deltaY;

		return result;
	}
}

float impulse_circle_get_radius(impulse_shape_t *s)
{
	return (s != NULL && s->type == IMPULSE_SHAPE_CIRCLE) ? s->circle.radius : 0.0f;
}

impulse_vec2_t impulse_rectangle_get_dimensions(impulse_shape_t *s)
{
	if (!impulse_shape_is_rectangle(s)) return IMPULSE_STRUCT_ZERO(impulse_vec2_t);

	return (impulse_vec2_t){
	        s->polygon.vertices.data[2].x - s->polygon.vertices.data[1].x,
	        s->polygon.vertices.data[1].y - s->polygon.vertices.data[0].y};
}

impulse_vec2_t impulse_polygon_get_vertex(impulse_shape_t *s, int index)
{
	return (s != NULL && index >= 0 && index < s->polygon.vertices.count)
	               ? s->polygon.vertices.data[index]
	               : IMPULSE_STRUCT_ZERO(impulse_vec2_t);
}

impulse_vec2_t impulse_polygon_get_normal(impulse_shape_t *s, int index)
{
	return (s != NULL && index >= 0 && index < s->polygon.normals.count)
	               ? s->polygon.normals.data[index]
	               : IMPULSE_STRUCT_ZERO(impulse_vec2_t);
}

impulse_vertices_t impulse_polygon_get_vertices(impulse_shape_t *s)
{
	return (s != NULL) ? s->polygon.vertices : IMPULSE_STRUCT_ZERO(impulse_vertices_t);
}

impulse_vertices_t impulse_polygon_get_normals(impulse_shape_t *s)
{
	return (s != NULL) ? s->polygon.normals : IMPULSE_STRUCT_ZERO(impulse_vertices_t);
}

bool impulse_shape_is_rectangle(impulse_shape_t *s)
{
	return (s != NULL) && (s->type == IMPULSE_SHAPE_POLYGON) && s->is_rect;
}

void impulse_circle_set_radius(impulse_shape_t *s, float radius)
{
	if (s == NULL || s->type != IMPULSE_SHAPE_CIRCLE) return;

	s->circle.radius = radius;

	impulse_compute_area(s);
}

void impulse_rectangle_set_dimensions(impulse_shape_t *s, impulse_vec2_t wh)
{
	if (!impulse_shape_is_rectangle(s) || wh.x <= 0.0f || wh.y <= 0.0f) return;

	wh = impulse_vec2_scalar_mult(wh, 0.5f);

	impulse_vertices_t vertices = {
	        .data = {
	                impulse_vec2(-wh.x,  -wh.y),
	                impulse_vec2(-wh.x,  wh.y),
	                impulse_vec2(wh.x,  wh.y),
	                impulse_vec2(wh.x,  -wh.y)},
	        .count = 4};

	impulse_polygon_set_vertices(s, vertices);
}

void impulse_polygon_set_vertices(impulse_shape_t *s, impulse_vertices_t vertices)
{
	int i, j;

	if (s == NULL || s->type != IMPULSE_SHAPE_POLYGON) return;

	s->polygon.vertices.count = vertices.count;
	s->polygon.normals.count  = vertices.count;

	for ( i = 0; i < vertices.count; i++)
		s->polygon.vertices.data[i] = vertices.data[i];


	if (!s->is_rect) impulse_compute_convex(s);

	impulse_compute_area(s);

	for ( j = vertices.count - 1, i = 0; i < vertices.count; j = i, i++)
		s->polygon.normals.data[i] = impulse_vec2_left_norm(
		        impulse_vec2_sub(
		                s->polygon.vertices.data[i],
		                s->polygon.vertices.data[j]));
}

void impulse_shape_set_material(impulse_shape_t *s, impulse_material_t material)
{
	if (s != NULL) s->material = material;
}

void impulse_shape_set_type(impulse_shape_t *s, impulse_shape_type_t type)
{
	if (s != NULL && s->type != type) s->type = type;
}

bool impulse_shape_is_contain_point(impulse_shape_t *s, impulse_transform_t tx, impulse_vec2_t p)
{
	if (s == NULL || s->type == IMPULSE_SHAPE_UNKNOWN) return false;

	Rectangle aabb = impulse_shape_get_AABB(s, tx);


	if (p.x < aabb.x || p.x > aabb.x + aabb.width || p.y < aabb.y || p.y > aabb.y + aabb.height)
		return false;

	if (s->type == IMPULSE_SHAPE_CIRCLE) {
		float deltaX = p.x - tx.position.x;
		float deltaY = p.y - tx.position.y;

		float radius = impulse_circle_get_radius(s);

		return (deltaX * deltaX) + (deltaY * deltaY) <= radius * radius;
	} else if (s->type == IMPULSE_SHAPE_POLYGON) {
		impulse_raycast_hit_t raycast = impulse_raycast_check_shape(
		        s, tx,
		        (impulse_ray_t){p, impulse_vec2(1.0f, 0.f),  FLT_MAX});

		return raycast.inside;
	}
}

static void impulse_compute_area(impulse_shape_t *s)
{
	if (s == NULL || s->type == IMPULSE_SHAPE_UNKNOWN) {
		s->area = 0.0f;
	} else if (s->type == IMPULSE_SHAPE_CIRCLE) {
		s->area = PI * (s->circle.radius * s->circle.radius);
	} else if (s->type == IMPULSE_SHAPE_POLYGON) {
		if (s->is_rect) {
			impulse_vertices_t *vertices = &(s->polygon.vertices);

			float width  = vertices->data[2].x - vertices->data[1].x;
			float height = vertices->data[1].y - vertices->data[0].y;

			s->area = width * height;
		} else {
			float twiceAreaSum = 0.0f;
			int i;

			for ( i = 0; i < s->polygon.vertices.count - 1; i++) {
				float twiceArea = impulse_vec2_cross_product(
				        impulse_vec2_sub(s->polygon.vertices.data[i], s->polygon.vertices.data[0]),
				        impulse_vec2_sub(s->polygon.vertices.data[i + 1], s->polygon.vertices.data[0]));

				twiceAreaSum += twiceArea;
			}

			s->area = fabsf(0.5f * twiceAreaSum);
		}
	}
}

static void impulse_compute_convex(impulse_shape_t *s)
{
	int i;
	if (s == NULL || s->type != IMPULSE_SHAPE_POLYGON) return;

	impulse_vertices_t result = impulse_jarvis_march(&(s->polygon.vertices));

	for ( i = 0; i < result.count; i++)
		s->polygon.vertices.data[i] = result.data[i];

	s->polygon.vertices.count = result.count;
}

static impulse_vertices_t impulse_jarvis_march(impulse_vertices_t *vertices)
{
	int i;

	if (vertices == NULL || vertices->count == 0) return IMPULSE_STRUCT_ZERO(impulse_vertices_t);

	impulse_vertices_t result = IMPULSE_STRUCT_ZERO(impulse_vertices_t);

	int leftmostIndex = 0, pivotIndex = 0, nextIndex = 0, vertexCount = 0;


	for ( i = 1; i < vertices->count; i++)
		if (vertices->data[leftmostIndex].x > vertices->data[i].x)
			leftmostIndex = i;

	result.data[vertexCount++] = vertices->data[leftmostIndex];


	pivotIndex = leftmostIndex;

	for (;;) {

		for ( i = 0; i < vertices->count; i++) {
			if (i == pivotIndex)
				continue;

			nextIndex = i;

			break;
		}

		for ( i = 0; i < vertices->count; i++) {
			if (i == pivotIndex || i == nextIndex)
				continue;


			if (impulse_vec2_ccw(vertices->data[pivotIndex], vertices->data[i], vertices->data[nextIndex]))
				nextIndex = i;
		}

		if (nextIndex == leftmostIndex)
			break;

		pivotIndex = nextIndex;


		result.data[vertexCount++] = vertices->data[nextIndex];
	}

	result.count = vertexCount;

	return result;
}
