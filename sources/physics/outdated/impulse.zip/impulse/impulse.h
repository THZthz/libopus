#ifndef IMPULSE_H
#define IMPULSE_H

#include <float.h>
#include <math.h>
#include <stdint.h>
#include <stdlib.h>
#include <assert.h>

#ifndef bool
#define bool int
#define true 1
#define false 0
#endif /* bool */

#ifndef IMPULSE_STANDALONE
#include <raylib.h>
/**
 * @brief specially for raylib rendering
 */
#define impulse_vec_cast(v) (*(Vector2 *) &(v))
#endif /* IMPULSE_STANDALONE */

#ifndef PI
#define PI 3.14159265358979323846f
#endif /* PI */

#define impulse_deg2rad(deg) ((deg) * PI / 180.0f)
#define impulse_rad_2deg(rad) ((rad) * 180.0f / PI)

typedef struct impulse_vec2_ {
	float x;
	float y;
} impulse_vec2_t;

/*typedef struct Rectangle {
    float x;
    float y;
    float width;
    float height;
} Rectangle;*/

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

bool impulse_is_rect_collided(Rectangle rec1, Rectangle rec2);

#ifdef __cplusplus
};
#endif /* __cplusplus */

#ifdef _MSC_VER
#define IMPULSE_API_INLINE __forceinline
#elif defined(__GNUC__)
#if defined(__STRICT_ANSI__)
#define IMPULSE_INLINE_API __inline__ __attribute__((always_inline))
#else
#define IMPULSE_INLINE_API inline __attribute__((always_inline))
#endif
#else
#define IMPULSE_INLINE_API
#endif

#define IMPULSE_STRUCT_ZERO(T) ((T){0})
#define IMPULSE_ASSERT(c) assert(c)
#define IMPULSE_NOT_NULL(v) IMPULSE_ASSERT((v) != NULL)
#define IMPULSE_RET_EMPTY(type) do {type emp_ = {0}; return emp_;}while(0)
#define IMPULSE_RET_EMPTY_IF(cond, type) if (cond) IMPULSE_RET_EMPTY(type);
#define IMPULSE_RET_EMPTY_IF_NULL(v, type) if ((v) == NULL) IMPULSE_RET_EMPTY(type);

#define impulse_abs(v) ((v) < 0 ? -(v) : (v))
#define impulse_sqrt(v) ((IMPULSE_REAL_TYPE) sqrt((double) (v)))
#define impulse_sin(v) ((IMPULSE_REAL_TYPE) sin((double) (v)))
#define impulse_cos(v) ((IMPULSE_REAL_TYPE) cos((double) (v)))
#define impulse_atan2(y, x) ((IMPULSE_REAL_TYPE) atan2((double) (y), (double) (x)))
#define impulse_floor(v) ((IMPULSE_REAL_TYPE) floor((double) (v)))

#define IMPULSE_REAL_TYPE float
#define IMPULSE_REAL_MAX FLT_MAX

#define IMPULSE_BROADPHASE_CELL_SIZE 3.2f
#define IMPULSE_BROADPHASE_INVERSE_CELL_SIZE (1.0f / (IMPULSE_BROADPHASE_CELL_SIZE))

#define IMPULSE_DEBUG_CIRCLE_SEGMENT_COUNT 32

#define IMPULSE_DYNAMICS_CORRECTION_DEPTH_SCALE 0.24f
#define IMPULSE_DYNAMICS_CORRECTION_DEPTH_THRESHOLD 0.02f
#define IMPULSE_DYNAMICS_DYNAMIC_FRICTION_MULTIPLIER 0.85f

#define IMPULSE_GEOMETRY_MAX_VERTEX_COUNT 8

#define IMPULSE_GLOBAL_PIXELS_PER_METER 16.0f

#define IMPULSE_WORLD_ACCUMULATOR_LIMIT 200.0
#define IMPULSE_WORLD_DEFAULT_GRAVITY ((impulse_vec2_t){.y = 9.8f})
#define IMPULSE_WORLD_MAX_BODY_COUNT 256
#define IMPULSE_WORLD_MAX_ITERATIONS 5

typedef enum impulse_body_type {
	IMPULSE_BODY_UNKNOWN = -1,
	IMPULSE_BODY_STATIC,
	IMPULSE_BODY_KINEMATIC,
	IMPULSE_BODY_DYNAMIC
} impulse_body_type_t;

typedef enum impulse_body_flag {
	IMPULSE_FLAG_NONE             = 0x00,
	IMPULSE_FLAG_INFINITE_MASS    = 0x01,
	IMPULSE_FLAG_INFINITE_INERTIA = 0x02
} impulse_body_flag_t;

typedef uint8_t impulse_body_flags_t;

typedef enum impulse_shape_type {
	IMPULSE_SHAPE_UNKNOWN,
	IMPULSE_SHAPE_CIRCLE,
	IMPULSE_SHAPE_POLYGON
} impulse_shape_type_t;

typedef struct impulse_material {
	float density;
	float restitution;
	float static_friction;
	float dynamic_friction;
} impulse_material_t;

typedef struct impulse_transform {
	impulse_vec2_t position;
	float          rotation;
	struct {
		bool  valid;
		float sin_a;
		float cos_a;
	} cache;
} impulse_transform_t;

typedef struct impulse_vertices {
	impulse_vec2_t data[IMPULSE_GEOMETRY_MAX_VERTEX_COUNT];
	int            count;
} impulse_vertices_t;

typedef struct impulse_shape impulse_shape_t;
typedef struct impulse_body impulse_body_t;

struct impulse_shape {
	impulse_shape_type_t type;
	impulse_material_t   material;

	impulse_body_t *body;

	bool  is_rect;
	float area;
	union
	{
		struct {
			float radius;
		} circle;
		struct {
			impulse_vertices_t vertices;
			impulse_vertices_t normals;
		} polygon;
	};
};

struct impulse_motion_data {
	float          mass;
	float          inverseMass;
	float          inertia;
	float          inverseInertia;
	impulse_vec2_t velocity;
	float          angularVelocity;
	float          gravityScale;
	impulse_vec2_t force;
	float          torque;
};

struct impulse_body {
	impulse_body_type_t        type;
	impulse_body_flags_t       flags;
	impulse_material_t         material;
	struct impulse_motion_data motion;
	impulse_transform_t        tx;
	impulse_shape_t           *shape;
	Rectangle                  aabb;
	void                      *data;
};

typedef struct impulse_solver_cache {
	impulse_body_t *bodies[2];
} impulse_solver_cache_t;

typedef struct impulse_collision {
	bool                   check;
	impulse_solver_cache_t cache;
	impulse_vec2_t         direction;
	impulse_vec2_t         points[2];
	float                  depths[2];
	int                    count;
	impulse_shape_t *a_, *b_;
} impulse_collision_t;

typedef void (*impulse_collision_cb_t)(impulse_collision_t *collision);

typedef struct impulse_collision_handler {
	impulse_collision_cb_t pre_solve;
	impulse_collision_cb_t post_solve;
} impulse_collision_handler_t;

typedef struct impulse_ray {
	impulse_vec2_t origin;
	impulse_vec2_t direction;
	float          max_dist;
	bool           closest;
} impulse_ray_t;

typedef struct impulse_raycast_hit {
	bool check;
	union
	{
		impulse_shape_t *shape;
		impulse_body_t  *body;
	};
	impulse_vec2_t point;
	impulse_vec2_t normal;
	float          distance;
	bool           inside;
} impulse_raycast_hit_t;

typedef struct impulse_world         impulse_world_t;
typedef struct impulse_spatial_entry impulse_spatial_entry_t;
typedef struct impulse_spatial_hash  impulse_spatial_hash_t;

struct impulse_world {
	impulse_vec2_t              gravity;
	impulse_body_t            **bodies;
	impulse_spatial_hash_t     *hash;
	impulse_collision_t        *collisions;
	impulse_collision_handler_t handler;
	double                      accumulator;
	double                      timestamp;
	int                        *queries;
};

struct impulse_spatial_entry {
	int  key;
	int *values;
};

struct impulse_spatial_hash {
	Rectangle                bounds;
	float                    cell_size;
	float                    inv_cell_size;
	impulse_spatial_entry_t *entries;
	int                     *query_cache;
};

#ifdef __cplusplus
extern "C" {
#endif

/****************************************************
 * SPATIAL HASH
 ****************************************************/

impulse_spatial_hash_t *impulse_spatial_hash_create(Rectangle bounds, float cell_size);
void                    impulse_spatial_hash_destroy(impulse_spatial_hash_t *hash);
void                    impulse_spatial_hash_add(impulse_spatial_hash_t *hash, Rectangle bound, int value);
void                    impulse_spatial_hash_clear(impulse_spatial_hash_t *hash);
void                    impulse_spatial_hash_remove(impulse_spatial_hash_t *hash, int key);
void                    impulse_spatial_hash_query(impulse_spatial_hash_t *hash, Rectangle rec, int **result);
void                    impulse_spatial_hash_set_bounds(impulse_spatial_hash_t *hash, Rectangle bounds);
Rectangle               impulse_spatial_hash_get_bounds(impulse_spatial_hash_t *hash);
float                   impulse_spatial_get_hash_cell_size(impulse_spatial_hash_t *hash);
void                    impulse_spatial_set_hash_bounds(impulse_spatial_hash_t *hash, Rectangle bounds);
void                    impulse_spatial_set_hash_cell_size(impulse_spatial_hash_t *hash, float cell_size);

impulse_collision_t impulse_collision_check_shape(impulse_shape_t *s1, impulse_transform_t tx1, impulse_shape_t *s2, impulse_transform_t tx2);
impulse_collision_t impulse_collision_check_body(impulse_body_t *b1, impulse_body_t *b2);

impulse_raycast_hit_t impulse_raycast_check_shape(impulse_shape_t *s, impulse_transform_t tx, impulse_ray_t ray);
impulse_raycast_hit_t impulse_raycast_check_body(impulse_body_t *b, impulse_ray_t ray);


#ifndef IMPULSE_STANDALONE
void  impulse_draw_arrow(impulse_vec2_t p1, impulse_vec2_t p2, float thick, Color color);
void  impulse_draw_body(impulse_body_t *b, Color color);
void  impulse_draw_body_lines(impulse_body_t *b, float thick, Color color);
void  impulse_draw_body_AABB(impulse_body_t *b, float thick, Color color);
void  impulse_draw_body_props(impulse_body_t *b, Color color);
void  impulse_draw_spatial_hash(impulse_spatial_hash_t *hm, float thick, Color color);
Color impulse_draw_get_rand_color(void);
#endif

impulse_body_t      *impulse_body_create(impulse_body_type_t type, impulse_body_flags_t flags, impulse_vec2_t p);
impulse_body_t      *impulse_body_create_from_shape(impulse_body_type_t type, impulse_body_flags_t flags, impulse_vec2_t p, impulse_shape_t *s);
void                 impulse_body_destroy(impulse_body_t *b);
void                 impulse_body_attach_shape(impulse_body_t *b, impulse_shape_t *s);
void                 impulse_body_detach_shape(impulse_body_t *b);
impulse_body_type_t  impulse_body_get_type(impulse_body_t *b);
impulse_body_flags_t impulse_body_get_flags(impulse_body_t *b);
impulse_material_t   impulse_body_get_material(impulse_body_t *b);
float                impulse_body_get_mass(impulse_body_t *b);
float                impulse_body_get_inv_mass(impulse_body_t *b);
float                impulse_body_get_inertia(impulse_body_t *b);
float                impulse_body_get_inv_inertia(impulse_body_t *b);
impulse_vec2_t       impulse_body_get_velocity(impulse_body_t *b);
float                impulse_body_get_angular_velocity(impulse_body_t *b);
float                impulse_body_get_gravity_scale(impulse_body_t *b);
impulse_transform_t  impulse_body_get_transform(impulse_body_t *b);
impulse_vec2_t       impulse_body_get_position(impulse_body_t *b);
float                impulse_body_get_rotation(impulse_body_t *b);
impulse_shape_t     *impulse_body_get_shape(impulse_body_t *b);
Rectangle            impulse_body_get_AABB(impulse_body_t *b);
impulse_vec2_t       impulse_body_get_local_point(impulse_body_t *b, impulse_vec2_t p);
impulse_vec2_t       impulse_body_get_world_point(impulse_body_t *b, impulse_vec2_t p);
void                 impulse_body_set_type(impulse_body_t *b, impulse_body_type_t type);
void                 impulse_body_set_flags(impulse_body_t *b, impulse_body_flags_t flags);
void                 impulse_body_set_velocity(impulse_body_t *b, impulse_vec2_t v);
void                 impulse_body_set_angular_velocity(impulse_body_t *b, double a);
void                 impulse_body_set_gravity_scale(impulse_body_t *b, float scale);
void                 impulse_body_set_transform(impulse_body_t *b, impulse_transform_t tx);
void                 impulse_body_set_position(impulse_body_t *b, impulse_vec2_t p);
void                 impulse_body_set_rotation(impulse_body_t *b, float rotation);
void                 impulse_body_clear_forces(impulse_body_t *b);

void impulse_apply_gravity(impulse_body_t *b, impulse_vec2_t gravity);
void impulse_apply_impulse(impulse_body_t *b, impulse_vec2_t impulse);
void impulse_apply_torque_impulse(impulse_body_t *b, impulse_vec2_t p, impulse_vec2_t impulse);

void impulse_integrate_for_body_position(impulse_body_t *b, double dt);
void impulse_integrate_for_body_velocity(impulse_body_t *b, double dt);
void impulse_resolve_collision(impulse_collision_t *collision);
void impulse_correct_body_position(impulse_collision_t *collision, float inverseDt);

impulse_shape_t *impulse_circle_create(impulse_material_t material, float radius);
impulse_shape_t *impulse_rectangle_create(impulse_material_t material, float width, float height);
impulse_shape_t *impulse_polygon_create(impulse_material_t material, impulse_vertices_t vertices);


impulse_shape_t     *impulse_shape_create(void);
impulse_shape_t     *impulse_shape_clone(impulse_shape_t *s);
void                 impulse_shape_destroy(impulse_shape_t *s);
impulse_shape_type_t impulse_shape_get_type(impulse_shape_t *s);
impulse_material_t   impulse_shape_get_material(impulse_shape_t *s);
float                impulse_shape_get_area(impulse_shape_t *s);
float                impulse_shape_get_mass(impulse_shape_t *s);
float                impulse_shape_get_inertia(impulse_shape_t *s);
Rectangle            impulse_shape_get_AABB(impulse_shape_t *s, impulse_transform_t tx);

float              impulse_circle_get_radius(impulse_shape_t *s);
impulse_vec2_t     impulse_rectangle_get_dimensions(impulse_shape_t *s);
impulse_vec2_t     impulse_polygon_get_vertex(impulse_shape_t *s, int index);
impulse_vec2_t     impulse_polygon_get_normal(impulse_shape_t *s, int index);
impulse_vertices_t impulse_polygon_get_vertices(impulse_shape_t *s);
impulse_vertices_t impulse_polygon_get_normals(impulse_shape_t *s);
bool               impulse_shape_is_rectangle(impulse_shape_t *s);
void               impulse_circle_set_radius(impulse_shape_t *s, float radius);
void               impulse_rectangle_set_dimensions(impulse_shape_t *s, impulse_vec2_t wh);
void               impulse_polygon_set_vertices(impulse_shape_t *s, impulse_vertices_t vertices);


void impulse_shape_set_material(impulse_shape_t *s, impulse_material_t material);
void impulse_shape_set_type(impulse_shape_t *s, impulse_shape_type_t type);
bool impulse_shape_is_contain_point(impulse_shape_t *s, impulse_transform_t tx, impulse_vec2_t p);

/****************************************************
 * CLOCK
 ****************************************************/

void   impulse_clock_init(void);
double impulse_clock_get_current_time(void);
double impulse_clock_get_time_diff(double newTime, double oldTime);
double impulse_clock_get_time_since(double oldTime);

/****************************************************
 * VECTOR
 ****************************************************/

impulse_vec2_t impulse_vec2(float x, float y);
impulse_vec2_t impulse_vec2_add(impulse_vec2_t v1, impulse_vec2_t v2);
impulse_vec2_t impulse_vec2_sub(impulse_vec2_t v1, impulse_vec2_t v2);
impulse_vec2_t impulse_vec2_scalar_mult(impulse_vec2_t v, float value);
float          impulse_vec2_cross_product(impulse_vec2_t v1, impulse_vec2_t v2);
float          impulse_vec2_dot_product(impulse_vec2_t v1, impulse_vec2_t v2);
float          impulse_vec2_mag_sq(impulse_vec2_t v);
float          impulse_vec2_mag(impulse_vec2_t v);
impulse_vec2_t impulse_vec2_neg(impulse_vec2_t v);
impulse_vec2_t impulse_vec2_norm(impulse_vec2_t v);
float          impulse_vec2_ang(impulse_vec2_t v1, impulse_vec2_t v2);
bool           impulse_vec2_approx_eq(impulse_vec2_t v1, impulse_vec2_t v2);
impulse_vec2_t impulse_vec2_left_norm(impulse_vec2_t v);
impulse_vec2_t impulse_vec2_right_norm(impulse_vec2_t v);
impulse_vec2_t impulse_vec2_rotate(impulse_vec2_t v, float angle);
impulse_vec2_t impulse_vec2_rotate_tx(impulse_vec2_t v, impulse_transform_t tx);
impulse_vec2_t impulse_vec2_transform(impulse_vec2_t v, impulse_transform_t tx);
bool           impulse_vec2_ccw(impulse_vec2_t v1, impulse_vec2_t v2, impulse_vec2_t v3);
impulse_vec2_t impulse_vec2_m2p(impulse_vec2_t v);
impulse_vec2_t impulse_vec2_p2m(impulse_vec2_t v);

/****************************************************
 * UTILS
 ****************************************************/

float     impulse_num_p2m(float value);
float     impulse_num_m2p(float value);
Rectangle impulse_rect_p2m(Rectangle rect);
Rectangle impulse_rect_m2p(Rectangle rect);
float     impulse_min(float a, float b);
float     impulse_max(float a, float b);
float     impulse_norm_angle(float angle, float center);
bool      impulse_num_approx_eq(float f1, float f2);

/****************************************************
 * WORLD
 ****************************************************/

impulse_world_t            *impulse_world_create(impulse_vec2_t gravity, Rectangle bounds);
void                        impulse_world_destroy(impulse_world_t *world);
bool                        impulse_world_add(impulse_world_t *world, impulse_body_t *b);
void                        impulse_world_clear(impulse_world_t *world);
bool                        impulse_world_remove(impulse_world_t *world, impulse_body_t *b);
impulse_body_t             *impulse_world_get_body(impulse_world_t *world, int index);
impulse_collision_handler_t impulse_world_get_collision_handler(impulse_world_t *world);
int                         impulse_world_get_body_count(impulse_world_t *world);
Rectangle                   impulse_world_get_bounds(impulse_world_t *world);
impulse_spatial_hash_t     *impulse_world_get_spatial_hash(impulse_world_t *world);
impulse_vec2_t              impulse_world_get_gravity(impulse_world_t *world);
bool                        impulse_world_is_in_bounds(impulse_world_t *world, impulse_body_t *b);
void                        impulse_world_set_bounds(impulse_world_t *world, Rectangle bounds);
void                        impulse_world_set_collision_handler(impulse_world_t *world, impulse_collision_handler_t handler);
void                        impulse_world_set_gravity(impulse_world_t *world, impulse_vec2_t gravity);
void                        impulse_world_simulate(impulse_world_t *world, double dt);
int                         impulse_world_query_spatial_hash(impulse_world_t *world, Rectangle rec, impulse_body_t **bodies);
int                         impulse_world_compute_raycast(impulse_world_t *world, impulse_ray_t ray, impulse_raycast_hit_t *hits);


#ifdef __cplusplus
};
#endif

#endif
