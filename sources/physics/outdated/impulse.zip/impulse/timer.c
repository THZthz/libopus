﻿#include "impulse.h"


#if defined(_WIN32)
    #define NOGDI
    #define NOUSER
#endif

#define SOKOL_TIME_IMPL
#include "core/external/sokol_time.h"

static bool initialized = false;

void impulse_clock_init(void) {
    if (!initialized) {
        initialized = true;
        stm_setup();
    }
} 

double impulse_clock_get_current_time(void) {
    if (!initialized) impulse_clock_init();
    
    return stm_ms(stm_now());
}

double impulse_clock_get_time_diff(double newTime, double oldTime) {
    return newTime - oldTime;
}

double impulse_clock_get_time_since(double oldTime) {
    return impulse_clock_get_time_diff(impulse_clock_get_current_time(), oldTime);
}
