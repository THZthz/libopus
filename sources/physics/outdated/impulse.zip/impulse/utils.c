﻿#include "impulse.h"

#define STB_DS_IMPLEMENTATION
#include "core/external/STB/stb_ds.h"

#define TWO_PI (2.0f * PI)

const float INVERSE_TWO_PI = (1.0f / TWO_PI);

float impulse_norm_angle(float angle, float center)
{
	if (angle > center - PI && angle < center + PI) return angle;

	return angle - (TWO_PI * impulse_floor((angle + PI - center) * INVERSE_TWO_PI));
}

bool impulse_num_approx_eq(float f1, float f2)
{
	return fabsf(f1 - f2) <= impulse_max(f1, f2) * FLT_EPSILON;
}

float impulse_num_p2m(float value)
{
	IMPULSE_ASSERT(IMPULSE_GLOBAL_PIXELS_PER_METER > 0.0f);
	return value / IMPULSE_GLOBAL_PIXELS_PER_METER;
}

float impulse_num_m2p(float value)
{
	IMPULSE_ASSERT(IMPULSE_GLOBAL_PIXELS_PER_METER > 0.0f);
	return (value * IMPULSE_GLOBAL_PIXELS_PER_METER);
}

Rectangle impulse_rect_p2m(Rectangle rect)
{
	rect.x      = impulse_num_p2m(rect.x);
	rect.y      = impulse_num_p2m(rect.y);
	rect.width  = impulse_num_p2m(rect.width);
	rect.height = impulse_num_p2m(rect.height);
	return rect;
}

Rectangle impulse_rect_m2p(Rectangle rect)
{
	rect.x      = impulse_num_m2p(rect.x);
	rect.y      = impulse_num_m2p(rect.y);
	rect.width  = impulse_num_m2p(rect.width);
	rect.height = impulse_num_m2p(rect.height);
	return rect;
}

float impulse_min(float a, float b)
{
	return a < b ? a : b;
}

float impulse_max(float a, float b)
{
	return a > b ? a : b;
}

impulse_vec2_t impulse_vec2(float x, float y)
{
	impulse_vec2_t vec;
	vec.x = x;
	vec.y = y;
	return vec;
}

impulse_vec2_t impulse_vec2_add(impulse_vec2_t v1, impulse_vec2_t v2)
{
	v1.x += v2.x;
	v1.y += v2.y;
	return v1;
}

impulse_vec2_t impulse_vec2_sub(impulse_vec2_t v1, impulse_vec2_t v2)
{
	v1.x -= v2.x;
	v1.y -= v2.y;
	return v1;
}

impulse_vec2_t impulse_vec2_scalar_mult(impulse_vec2_t v, float value)
{
	v.x *= value;
	v.y *= value;
	return v;
}

float impulse_vec2_cross_product(impulse_vec2_t v1, impulse_vec2_t v2)
{
	return (v1.x * v2.y) - (v1.y * v2.x);
}

float impulse_vec2_dot_product(impulse_vec2_t v1, impulse_vec2_t v2)
{
	return (v1.x * v2.x) + (v1.y * v2.y);
}

float impulse_vec2_mag_sq(impulse_vec2_t v)
{
	return impulse_vec2_dot_product(v, v);
}

float impulse_vec2_mag(impulse_vec2_t v)
{
	return (float) sqrt((double) impulse_vec2_mag_sq(v));
}

impulse_vec2_t impulse_vec2_neg(impulse_vec2_t v)
{
	return impulse_vec2(-v.x, -v.y);
}

impulse_vec2_t impulse_vec2_norm(impulse_vec2_t v)
{
	return impulse_vec2_scalar_mult(v, 1.0f / impulse_vec2_mag(v));
}

float impulse_vec2_ang(impulse_vec2_t v1, impulse_vec2_t v2)
{
	return impulse_atan2(v2.y, v2.x) - impulse_atan2(v1.y, v1.x);
}

bool impulse_vec2_approx_eq(impulse_vec2_t v1, impulse_vec2_t v2)
{
	return impulse_num_approx_eq(v1.x, v2.x) && impulse_num_approx_eq(v1.y, v2.y);
}

impulse_vec2_t impulse_vec2_left_norm(impulse_vec2_t v)
{
	return impulse_vec2_norm(impulse_vec2(-v.y, v.x));
}

impulse_vec2_t impulse_vec2_right_norm(impulse_vec2_t v)
{
	return impulse_vec2_norm(impulse_vec2(v.y, -v.x));
}

/**
 * @brief rotate vector in clockwise
 * @param angle in radian
 */
impulse_vec2_t impulse_vec2_rotate(impulse_vec2_t v, float angle)
{
	float s = impulse_sin(angle);
	float c = impulse_cos(angle);

	return impulse_vec2(v.x * c - v.y * s,
	                    v.x * s + v.y * c);
}

impulse_vec2_t impulse_vec2_rotate_tx(impulse_vec2_t v, impulse_transform_t tx)
{
	if (!tx.cache.valid)
		return impulse_vec2_rotate(v, tx.rotation);
	else {
		impulse_vec2_t ret;
		ret.x = v.x * tx.cache.cos_a - v.y * tx.cache.sin_a;
		ret.y = v.x * tx.cache.sin_a + v.y * tx.cache.cos_a;
		return ret;
	}
}

impulse_vec2_t impulse_vec2_transform(impulse_vec2_t v, impulse_transform_t tx)
{
	return impulse_vec2_add(tx.position, impulse_vec2_rotate_tx(v, tx));
}

bool impulse_vec2_ccw(impulse_vec2_t v1, impulse_vec2_t v2, impulse_vec2_t v3)
{
	return (v3.y - v1.y) * (v2.x - v1.x) < (v2.y - v1.y) * (v3.x - v1.x);
}

/**
 * @brief pixels to meters
 */
impulse_vec2_t impulse_vec2_p2m(impulse_vec2_t v)
{
	IMPULSE_ASSERT(IMPULSE_GLOBAL_PIXELS_PER_METER > 0.0f);
	return impulse_vec2_scalar_mult(v, 1.0f / IMPULSE_GLOBAL_PIXELS_PER_METER);
}

impulse_vec2_t impulse_vec2_m2p(impulse_vec2_t v)
{
	IMPULSE_ASSERT(IMPULSE_GLOBAL_PIXELS_PER_METER > 0.0f);
	return impulse_vec2_scalar_mult(v, IMPULSE_GLOBAL_PIXELS_PER_METER);
}

bool impulse_is_rect_collided(Rectangle rec1, Rectangle rec2)
{
	return (rec1.x + rec1.width) - rec2.x >= 0 && (rec2.x + rec2.width) - rec1.x >= 0 &&
	       (rec1.y + rec1.height) - rec2.y >= 0 && (rec2.y + rec2.height) - rec1.y >= 0;
}

/*              |     (middle)   |
 *     (left)  [S]--------------[E]  (right)
 *             |     (middle)   |
 */
/**
 * @brief determine which voronoi region a point is on a line segment.
 * 	Assume that both the line and the point are relative to `(0,0)`
 * @return -1 if in left voronoi region
 * 		   0 if in middle voronoi region
 * 		   1 if in right voronoi region
 */
int impulse_voronoi_region(const impulse_vec2_t line, const impulse_vec2_t point)
{
	float len2 = impulse_vec2_mag_sq(line);
	float dp   = impulse_vec2_dot_product(point, line);
	if (dp < 0) {
		return -1;
	} else if (dp > len2) {
		return 0;
	} else {
		return 1;
	}
}

