﻿#include "core/external/STB/stb_ds.h"
#include "impulse.h"

static void impulse_world_pre_update(impulse_world_t *world);
static void impulse_world_post_update(impulse_world_t *world);
static void impulse_world_update(impulse_world_t *world, double dt);

impulse_world_t *impulse_world_create(impulse_vec2_t gravity, Rectangle bounds) {
    impulse_world_t *result = calloc(1, sizeof(impulse_world_t));
    
    result->gravity = gravity;
    result->hash = impulse_spatial_hash_create(bounds, IMPULSE_BROADPHASE_CELL_SIZE);
    result->timestamp = impulse_clock_get_current_time();
    
    arrsetcap(result->bodies, IMPULSE_WORLD_MAX_BODY_COUNT);
    arrsetcap(result->collisions, IMPULSE_WORLD_MAX_BODY_COUNT * IMPULSE_WORLD_MAX_BODY_COUNT);
    arrsetcap(result->queries, IMPULSE_WORLD_MAX_BODY_COUNT);
    
    return result;
}

void impulse_world_destroy(impulse_world_t *world) {
	int i;
    if (world == NULL) return;
    
    for ( i = 0; i < arrlen(world->bodies); i++) {
        impulse_body_t *b = world->bodies[i];
        impulse_shape_t *s = impulse_body_get_shape(b);

        impulse_shape_destroy(s);
        impulse_body_destroy(b);
    }
    
    impulse_spatial_hash_destroy(world->hash);
    
    arrfree(world->bodies);
    arrfree(world->collisions);
    arrfree(world->queries);
    
    free(world);
}

bool impulse_world_add(impulse_world_t *world, impulse_body_t *b) {
    if (world == NULL || b == NULL || arrlen(world->bodies) >= IMPULSE_WORLD_MAX_BODY_COUNT)
        return false;
    
    arrput(world->bodies, b);
    
    return true;
}

void impulse_world_clear(impulse_world_t *world) {
    if (world == NULL) return;
    
    impulse_spatial_hash_clear(world->hash);
    
    arrsetlen(world->bodies, 0);
    arrsetlen(world->collisions, 0);
}

bool impulse_world_remove(impulse_world_t *world, impulse_body_t *b) {
	int i;
    if (world == NULL || b == NULL) return false;
    
    for ( i = 0; i < arrlen(world->bodies); i++) {
        if (world->bodies[i] == b) {
            arrdeln(world->bodies, i, 1);

            return true;
        }
    }
    
    return false;
}

impulse_body_t *impulse_world_get_body(impulse_world_t *world, int index) {
    return (world != NULL && index >= 0 && index < arrlen(world->bodies))
        ? world->bodies[index]
        : NULL;
}

impulse_collision_handler_t impulse_world_get_collision_handler(impulse_world_t *world) {
    return (world != NULL) ? world->handler : IMPULSE_STRUCT_ZERO(impulse_collision_handler_t);
}

int impulse_world_get_body_count(impulse_world_t *world) {
    return (world != NULL) ? arrlen(world->bodies) : 0;
}

Rectangle impulse_world_get_bounds(impulse_world_t *world) {
    return (world != NULL)
        ? impulse_spatial_hash_get_bounds(world->hash)
        : IMPULSE_STRUCT_ZERO(Rectangle);
}

impulse_spatial_hash_t *impulse_world_get_spatial_hash(impulse_world_t *world){
    return (world != NULL) ? world->hash : NULL;
}

impulse_vec2_t impulse_world_get_gravity(impulse_world_t *world) {
    return (world != NULL) ? world->gravity : IMPULSE_STRUCT_ZERO(impulse_vec2_t);
}

bool impulse_world_is_in_bounds(impulse_world_t *world, impulse_body_t *b) {
    if (world == NULL || b == NULL) return false;

    return CheckCollisionRecs(impulse_body_get_AABB(b), impulse_world_get_bounds(world));
}

void impulse_world_set_bounds(impulse_world_t *world, Rectangle bounds) {
    if (world != NULL) impulse_spatial_hash_set_bounds(world->hash, bounds);
}

void impulse_world_set_collision_handler(impulse_world_t *world, impulse_collision_handler_t handler) {
    if (world != NULL) world->handler = handler;
}

void impulse_world_set_gravity(impulse_world_t *world, impulse_vec2_t gravity) {
    if (world != NULL) world->gravity = gravity;
}

void impulse_world_simulate(impulse_world_t *world, double dt) {
    if (world == NULL || dt == 0.0f) return;
    
    double currentTime = impulse_clock_get_current_time();
    double elapsedTime = impulse_clock_get_time_diff(currentTime, world->timestamp);

    world->accumulator += elapsedTime;
    world->timestamp = currentTime;
    
    if (world->accumulator > IMPULSE_WORLD_ACCUMULATOR_LIMIT)
        world->accumulator = IMPULSE_WORLD_ACCUMULATOR_LIMIT;
    
	while(world->accumulator >= dt) {
		impulse_world_update(world, dt);
		world->accumulator -= dt;
	}
}

int impulse_world_query_spatial_hash(impulse_world_t *world, Rectangle rec, impulse_body_t **bodies) {
	int i;
    if (world == NULL || bodies == NULL) return 0;

    arrsetlen(world->queries, 0);

    for ( i = 0; i < arrlen(world->bodies); i++)
        impulse_spatial_hash_add(world->hash, impulse_body_get_AABB(world->bodies[i]), i);

    impulse_spatial_hash_query(world->hash, rec, &world->queries);

    int result = arrlen(world->queries);

    for ( i = 0; i < result; i++)
        bodies[i] = world->bodies[world->queries[i]];

    impulse_spatial_hash_clear(world->hash);

    return result;
}

int impulse_world_compute_raycast(impulse_world_t *world, impulse_ray_t ray, impulse_raycast_hit_t *hits) {

	int i;
    if (world == NULL || hits == NULL) return 0;

    arrsetlen(world->queries, 0);

    for ( i = 0; i < arrlen(world->bodies); i++)
        impulse_spatial_hash_add(world->hash, impulse_body_get_AABB(world->bodies[i]), i);

    impulse_vec2_t p1 = ray.origin, p2 = impulse_vec2_add(
        ray.origin, 
        impulse_vec2_scalar_mult(
            impulse_vec2_norm(ray.direction), 
            ray.max_dist)
    );

    Rectangle rec = (Rectangle) {
        .x = impulse_min(p1.x, p2.x),
        .y = impulse_min(p1.y, p2.y),
        .width = impulse_max(p2.x - p1.x, p1.x - p2.x),
        .height = impulse_max(p2.y - p1.y, p1.y - p2.y)
    };

    impulse_spatial_hash_query(world->hash, rec, &world->queries);

    if (arrlen(world->queries) <= 0) return 0;

    if (ray.closest) {
		int i;
        float minDistance = FLT_MAX;

        for ( i = 0; i < arrlen(world->queries); i++) {
            impulse_raycast_hit_t raycast = impulse_raycast_check_body(
                world->bodies[world->queries[i]], 
                ray
            );
            
            if (!raycast.check) continue;

            if (minDistance > raycast.distance) {
                minDistance = raycast.distance;
                hits[0] = raycast;
            }
        }

        impulse_spatial_hash_clear(world->hash);

        return 1;
    } else {
        int count = 0, i;

        for ( i = 0; i < arrlen(world->queries); i++) {
            impulse_raycast_hit_t raycast = impulse_raycast_check_body(
                world->bodies[world->queries[i]], 
                ray
            );

            if (raycast.check) hits[count++] = raycast;
        }

        impulse_spatial_hash_clear(world->hash);

        return count;
    }
}

static void impulse_world_pre_update(impulse_world_t *world) {
	int i, k;
    if (world == NULL || world->hash == NULL) return;

    for ( i = 0; i < arrlen(world->bodies); i++)
        impulse_spatial_hash_add(world->hash, impulse_body_get_AABB(world->bodies[i]), i);
    
    for ( i = 0; i < arrlen(world->bodies); i++) {
        impulse_spatial_hash_query(
            world->hash, 
            impulse_body_get_AABB(world->bodies[i]), 
            &world->queries
        );
        
        for ( k = 0; k < arrlen(world->queries); k++) {
            int j = world->queries[k];

			impulse_body_t *b1, *b2;
			impulse_collision_t collision;

            if (j <= i) continue;
            
            b1 = world->bodies[i];
            b2 = world->bodies[j];
            
             collision = impulse_collision_check_body(b1, b2);
            
            if (collision.check) {
                collision.cache.bodies[0] = b1;
                collision.cache.bodies[1] = b2;

                arrput(world->collisions, collision);
            }
        }
        
        arrsetlen(world->queries, 0);
    }
}

static void impulse_world_post_update(impulse_world_t *world) {
	int i;
    if (world == NULL || world->hash == NULL) return;

    for ( i = 0; i < arrlen(world->bodies); i++)
        impulse_body_clear_forces(world->bodies[i]);
    
    arrsetlen(world->collisions, 0);
    
    impulse_spatial_hash_clear(world->hash);
}

static void impulse_world_update(impulse_world_t *world, double dt) {
    int i, j, k;
	if (world == NULL || world->bodies == NULL || world->collisions == NULL) return;

    impulse_world_pre_update(world);
    
    
    for ( i = 0; i < arrlen(world->collisions); i++) {
        impulse_collision_cb_t preSolveCallback = world->handler.pre_solve;
        
        if (preSolveCallback != NULL) preSolveCallback(&world->collisions[i]);
    }

    for ( i = 0; i < arrlen(world->bodies); i++) {
        impulse_apply_gravity(world->bodies[i], world->gravity);
		impulse_integrate_for_body_velocity(world->bodies[i], dt);
    }
    
    for ( i = 0; i < IMPULSE_WORLD_MAX_ITERATIONS; i++)
        for ( j = 0; j < arrlen(world->collisions); j++)
            impulse_resolve_collision(&world->collisions[j]);
    
    for ( i = 0; i < arrlen(world->bodies); i++)
        impulse_integrate_for_body_position(world->bodies[i], dt);
    
    float inverseDt = (dt != 0.0f) ? (1.0f / dt) : 0.0f;
    
    for ( i = 0; i < arrlen(world->collisions); i++)
        impulse_correct_body_position(&world->collisions[i], inverseDt);

    for ( i = 0; i < arrlen(world->collisions); i++) {
        impulse_collision_cb_t cb = world->handler.post_solve;
        if (cb != NULL) cb(&world->collisions[i]);
    }
    
    impulse_world_post_update(world);
}
